# ==========================================================
# DATABASE MODULE
# Handles MySQL connection and prediction storage
# ==========================================================

import pymysql
from datetime import datetime, date

# ----------------------------------------------------------
# DATABASE CONFIGURATION
# ----------------------------------------------------------

DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "root",   # change if different
    "database": "thyroid_ai"
}

# ----------------------------------------------------------
# CREATE DATABASE CONNECTION
# ----------------------------------------------------------

def get_connection():

    try:

        conn = pymysql.connect(
            host=DB_CONFIG["host"],
            user=DB_CONFIG["user"],
            password=DB_CONFIG["password"],
            database=DB_CONFIG["database"],
            cursorclass=pymysql.cursors.DictCursor
        )

        return conn

    except Exception as e:

        print("Database Connection Error:", e)
        return None


# ----------------------------------------------------------
# CREATE TABLE IF NOT EXISTS
# ----------------------------------------------------------

def create_table():

    conn = get_connection()

    if conn is None:
        return

    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS prediction_results (
        id INT AUTO_INCREMENT PRIMARY KEY,
        image_name VARCHAR(255),
        predicted_class VARCHAR(100),
        confidence FLOAT,
        model_name VARCHAR(100),
        segmentation_used BOOLEAN,
        processed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        patient_id VARCHAR(50),
        scan_date DATE,
        image_path VARCHAR(255),
        model_version VARCHAR(20),
        stage VARCHAR(100)
    )
    """)

    conn.commit()

    cursor.close()
    conn.close()

    print("Database table ready")


# ----------------------------------------------------------
# GENERATE PATIENT ID
# ----------------------------------------------------------

def generate_patient_id():

    conn = get_connection()

    if conn is None:
        return "P001"

    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) AS total FROM prediction_results")

    result = cursor.fetchone()

    total = result["total"] + 1

    cursor.close()
    conn.close()

    return f"P{total:03d}"


# ----------------------------------------------------------
# INSERT PREDICTION INTO DATABASE
# ----------------------------------------------------------

def save_prediction(
        image_name,
        predicted_class,
        confidence,
        stage,
        image_path,
        patient_id=None,
        model_version="v1.0"
    ):

    conn = None
    cursor = None

    try:

        conn = get_connection()

        if conn is None:
            print("Database connection failed")
            return

        cursor = conn.cursor()

        # Generate patient id if not provided
        if patient_id is None:
            patient_id = generate_patient_id()

        query = """
        INSERT INTO prediction_results
        (
            image_name,
            predicted_class,
            confidence,
            model_name,
            segmentation_used,
            patient_id,
            scan_date,
            image_path,
            model_version,
            stage
        )
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """

        values = (
            image_name,
            predicted_class,
            float(confidence),
            "InceptionV3",
            True,
            patient_id,
            date.today(),
            image_path,
            model_version,
            stage
        )

        cursor.execute(query, values)

        conn.commit()

        print("Prediction saved to database successfully")

    except Exception as e:

        print("Database Error:", e)

    finally:

        if cursor:
            cursor.close()

        if conn:
            conn.close()








# # ==========================================================
# # DATABASE MODULE
# # Handles MySQL connection and prediction storage
# # ==========================================================

# import pymysql
# from datetime import datetime, date

# # ----------------------------------------------------------
# # DATABASE CONFIGURATION
# # ----------------------------------------------------------

# DB_CONFIG = {
#     "host": "localhost",
#     "user": "root",
#     "password": "root",   # change if your password is different
#     "database": "thyroid_ai"
# }

# # ----------------------------------------------------------
# # CREATE CONNECTION
# # ----------------------------------------------------------

# def get_connection():

#     return pymysql.connect(
#         host=DB_CONFIG["host"],
#         user=DB_CONFIG["user"],
#         password=DB_CONFIG["password"],
#         database=DB_CONFIG["database"],
#         cursorclass=pymysql.cursors.DictCursor
#     )


# # ----------------------------------------------------------
# # CREATE TABLE IF NOT EXISTS (FULL PROFESSIONAL SCHEMA)
# # ----------------------------------------------------------

# def create_table():

#     conn = get_connection()
#     cursor = conn.cursor()

#     cursor.execute("""
#     CREATE TABLE IF NOT EXISTS prediction_results (
#         id INT AUTO_INCREMENT PRIMARY KEY,
#         image_name VARCHAR(255),
#         predicted_class VARCHAR(100),
#         confidence FLOAT,
#         model_name VARCHAR(100),
#         segmentation_used BOOLEAN,
#         processed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
#         patient_id VARCHAR(50),
#         scan_date DATE,
#         image_path VARCHAR(255),
#         model_version VARCHAR(20),
#         stage VARCHAR(100)
#     )
#     """)

#     conn.commit()
#     cursor.close()
#     conn.close()

#     print("Database table ready")


# # ----------------------------------------------------------
# # INSERT PREDICTION
# # ----------------------------------------------------------

# def save_prediction(
#         image_name,
#         predicted_class,
#         confidence,
#         stage,
#         image_path,
#         patient_id="P001",
#         model_version="v1.0"
#     ):

#     try:

#         conn = get_connection()
#         cursor = conn.cursor()

#         query = """
#         INSERT INTO prediction_results
#         (image_name, predicted_class, confidence, model_name,
#         segmentation_used, patient_id, scan_date,
#         image_path, model_version, stage)
#         VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
#         """

#         values = (
#             image_name,
#             predicted_class,
#             float(confidence),
#             "InceptionV3",
#             True,
#             patient_id,
#             date.today(),
#             image_path,
#             model_version,
#             stage
#         )

#         cursor.execute(query, values)
#         conn.commit()

#         print("Prediction saved to database successfully")

#     except Exception as e:

#         print("Database Error:", e)

#     finally:

#         cursor.close()
#         conn.close()