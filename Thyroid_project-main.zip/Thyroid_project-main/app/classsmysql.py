# ==========================================================
# THYROID IMAGE CLASSIFICATION + DB SAVE
# InceptionV3 + Multi-Scale CNN
# Recursively scans folders
# ==========================================================

import os
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
from tensorflow.keras.preprocessing.image import load_img, img_to_array, ImageDataGenerator
from tensorflow.keras.applications import InceptionV3
from tensorflow.keras.layers import *
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping
from sklearn.model_selection import train_test_split
import pymysql  # Make sure PyMySQL is installed

print("\n========== THYROID CLASSIFICATION ==========\n")

# ==========================================================
# PATH CONFIGURATION
# ==========================================================
BASE_PATH = r"C:\Users\ELCOT\Desktop\project"
DATASET_PATH = os.path.join(BASE_PATH, "Thyroid Classification Dataset1")
IMG_SIZE = 256
BATCH_SIZE = 8
EPOCHS = 15

# ==========================================================
# LOAD DATASET (Recursive)
# ==========================================================
X = []
Y = []
class_labels = []

for root, dirs, files in os.walk(DATASET_PATH):
    for folder in dirs:
        class_labels.append(folder)
class_labels = sorted(list(set(class_labels)))
class_mapping = {label: idx for idx, label in enumerate(class_labels)}

print("Detected Classes:", class_mapping)

# Recursive image loader
for class_label in class_labels:
    class_path = os.path.join(DATASET_PATH, class_label)
    for root, dirs, files in os.walk(class_path):
        for file in files:
            if file.lower().endswith(("jpg", "png", "jpeg")):
                img_path = os.path.join(root, file)
                img = load_img(img_path, target_size=(IMG_SIZE, IMG_SIZE))
                img = img_to_array(img) / 255.0
                X.append(img)
                Y.append(class_mapping[class_label])

X = np.array(X)
Y = np.array(Y)

if len(X) < 2:
    raise ValueError("Not enough images to train. Need at least 2 images.")

print("Total Images Loaded:", len(X))

# ==========================================================
# TRAIN / VALIDATION SPLIT
# ==========================================================
X_train, X_val, Y_train, Y_val = train_test_split(X, Y, test_size=0.2, random_state=42)

# ==========================================================
# DATA AUGMENTATION
# ==========================================================
datagen = ImageDataGenerator(rotation_range=15, zoom_range=0.1, horizontal_flip=True)
datagen.fit(X_train)

# ==========================================================
# MODEL BUILDING
# ==========================================================
print("\nBuilding Model...\n")

base_model = InceptionV3(weights='imagenet', include_top=False, input_shape=(IMG_SIZE, IMG_SIZE, 3))
base_model.trainable = False

x1 = GlobalAveragePooling2D()(base_model.output)

# Multi-scale CNN branch
input_layer = base_model.input
m1 = Conv2D(32, 3, activation='relu', padding='same')(input_layer)
m2 = Conv2D(32, 5, activation='relu', padding='same')(input_layer)
m3 = Conv2D(32, 7, activation='relu', padding='same')(input_layer)
multi_scale = Concatenate()([m1, m2, m3])
multi_scale = MaxPooling2D()(multi_scale)
multi_scale = GlobalAveragePooling2D()(multi_scale)

# Feature fusion
merged = Concatenate()([x1, multi_scale])
merged = Dense(256, activation='relu')(merged)
merged = Dropout(0.5)(merged)
output = Dense(len(class_labels), activation='softmax')(merged)

model = Model(inputs=input_layer, outputs=output)
model.compile(optimizer=Adam(1e-4), loss='sparse_categorical_crossentropy', metrics=['accuracy'])
model.summary()

# ==========================================================
# TRAINING
# ==========================================================
early_stop = EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)

model.fit(
    datagen.flow(X_train, Y_train, batch_size=BATCH_SIZE),
    validation_data=(X_val, Y_val),
    epochs=EPOCHS,
    callbacks=[early_stop]
)

# ==========================================================
# FINE TUNING LAST 30 LAYERS
# ==========================================================
for layer in base_model.layers[-30:]:
    layer.trainable = True

model.compile(optimizer=Adam(1e-5), loss='sparse_categorical_crossentropy', metrics=['accuracy'])
model.fit(datagen.flow(X_train, Y_train, batch_size=BATCH_SIZE), validation_data=(X_val, Y_val), epochs=5)

# ==========================================================
# DATABASE CONNECTION
# ==========================================================
conn = pymysql.connect(
    host="localhost",
    user="root",
    password="root",  # replace with your MySQL root password
    database="thyroid_ai"  # make sure this DB exists
)
cursor = conn.cursor()

# ==========================================================
# PREDICTION & SAVE TO DATABASE
# ==========================================================
for i in range(len(X_val)):
    sample = X_val[i]
    prediction = model.predict(np.expand_dims(sample, axis=0))
    confidence = float(np.max(prediction))
    predicted_class = class_labels[np.argmax(prediction)]
    image_name = f"val_image_{i+1}.jpg"  # or real filename if you saved names

    query = """
    INSERT INTO prediction_results
    (image_name, predicted_class, confidence, model_name, segmentation_used)
    VALUES (%s, %s, %s, %s, %s)
    """
    values = (image_name, predicted_class, confidence, "InceptionV3", True)
    cursor.execute(query, values)
    conn.commit()

    plt.imshow(sample)
    plt.title(f"Predicted: {predicted_class} ({confidence:.2f})")
    plt.axis("off")
    plt.show()

print("\nClassification + DB Save Completed Successfully")