# ==========================================================
# THYROID ROI EXTRACTION (PIXEL-LEVEL BACKGROUND REMOVAL)
# Output Size: 256 x 256 (CNN Ready)
# ==========================================================

import os
import cv2
import numpy as np

print("\n========== PIXEL-LEVEL ROI EXTRACTION (256x256) ==========\n")

# ================= PATH CONFIGURATION =================

BASE_PATH = r"C:\Users\ELCOT\Desktop\project"

IMAGE_PATH = os.path.join(
    BASE_PATH,
    "Thyroid Segmentation image1",
    "Thyroid Segmentation image1"
)

MASK_PATH = os.path.join(
    BASE_PATH,
    "Thyroid Segmentation mask1",
    "Thyroid Segmentation mask1"
)

OUTPUT_PATH = os.path.join(BASE_PATH, "ROI_256x256_Output")
os.makedirs(OUTPUT_PATH, exist_ok=True)

# ================= VALIDATION =================

if not os.path.exists(IMAGE_PATH):
    raise FileNotFoundError(f"Image folder not found → {IMAGE_PATH}")

if not os.path.exists(MASK_PATH):
    raise FileNotFoundError(f"Mask folder not found → {MASK_PATH}")

image_files = sorted(os.listdir(IMAGE_PATH))

# ================= ROI EXTRACTION =================

for file_name in image_files:

    img_file = os.path.join(IMAGE_PATH, file_name)
    mask_file = os.path.join(MASK_PATH, file_name)

    if not os.path.exists(mask_file):
        print(f"Mask missing → {file_name}")
        continue

    image = cv2.imread(img_file)
    mask = cv2.imread(mask_file, cv2.IMREAD_GRAYSCALE)

    if image is None or mask is None:
        print(f"Error loading → {file_name}")
        continue

    # Resize mask if needed
    if image.shape[:2] != mask.shape[:2]:
        mask = cv2.resize(mask, (image.shape[1], image.shape[0]))

    # Convert mask to binary
    _, binary_mask = cv2.threshold(mask, 127, 255, cv2.THRESH_BINARY)

    # Apply mask (remove background completely)
    roi = cv2.bitwise_and(image, image, mask=binary_mask)

    # Tight crop using bounding rectangle
    coords = cv2.findNonZero(binary_mask)
    if coords is not None:
        x, y, w, h = cv2.boundingRect(coords)
        roi = roi[y:y+h, x:x+w]

    # ================= IMPORTANT PART =================
    # Resize to 256x256 (CNN Ready)
    roi = cv2.resize(roi, (256, 256), interpolation=cv2.INTER_AREA)

    # Optional: Normalize (if training next)
    roi = roi.astype(np.float32) / 255.0

    # Save as uint8 image
    save_path = os.path.join(OUTPUT_PATH, file_name)
    cv2.imwrite(save_path, (roi * 255).astype(np.uint8))

    print(f"Processed → {file_name}")

print("\nROI Extraction Completed Successfully (256x256) ")