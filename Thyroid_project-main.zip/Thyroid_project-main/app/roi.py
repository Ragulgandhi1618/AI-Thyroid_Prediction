# ==========================================================
# ROI EXTRACTION MODULE (PIPELINE COMPATIBLE)
# Extract ROI from Segmented Image (NumPy Array Input)
# ==========================================================

import cv2
import numpy as np

print("\n========== ROI MODULE ==========\n")


# ----------------------------------------------------------
# MAIN ROI FUNCTION
# ----------------------------------------------------------

def extract_roi(image_array):
    """
    Extract ROI from segmented image.

    Input:
        image_array → segmented image (numpy array)

    Output:
        roi_image → cropped & resized ROI (numpy array)
    """

    try:
        if image_array is None:
            raise ValueError("Input image is None")

        # If normalized (0–1), convert to uint8
        if image_array.max() <= 1.0:
            image_array = (image_array * 255).astype(np.uint8)

        # Convert to grayscale
        gray = cv2.cvtColor(image_array, cv2.COLOR_RGB2GRAY)

        # Create binary mask
        _, thresh = cv2.threshold(gray, 1, 255, cv2.THRESH_BINARY)

        # Find contours
        contours, _ = cv2.findContours(
            thresh,
            cv2.RETR_EXTERNAL,
            cv2.CHAIN_APPROX_SIMPLE
        )

        if len(contours) == 0:
            print("No contours found. Returning original image.")
            roi = image_array
        else:
            # Get largest contour
            largest_contour = max(contours, key=cv2.contourArea)
            x, y, w, h = cv2.boundingRect(largest_contour)
            roi = image_array[y:y+h, x:x+w]

        # Resize to fixed size for classifier
        roi = cv2.resize(roi, (256, 256))

        # Normalize for model
        roi = roi.astype(np.float32) / 255.0

        print("ROI Extraction Completed Successfully")

        return roi

    except Exception as e:
        print("ROI Extraction Error:", e)
        return None