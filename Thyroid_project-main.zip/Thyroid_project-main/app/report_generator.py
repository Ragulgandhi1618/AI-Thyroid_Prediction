from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from datetime import datetime

def generate_report(image_name, prediction, confidence, stage):

    filename = f"reports/{image_name}_report.pdf"

    styles = getSampleStyleSheet()

    elements = []

    elements.append(Paragraph("AI Thyroid Diagnosis Report", styles['Title']))
    elements.append(Spacer(1,20))

    elements.append(Paragraph(f"Image: {image_name}", styles['Normal']))
    elements.append(Paragraph(f"Prediction: {prediction}", styles['Normal']))
    elements.append(Paragraph(f"Confidence: {confidence:.2f}%", styles['Normal']))
    elements.append(Paragraph(f"Clinical Stage: {stage}", styles['Normal']))
    elements.append(Paragraph(f"Model: InceptionV3", styles['Normal']))
    elements.append(Paragraph(f"Date: {datetime.now()}", styles['Normal']))

    pdf = SimpleDocTemplate(filename)

    pdf.build(elements)

    return filename
from fpdf import FPDF
from datetime import datetime

def generate_report(patient_name, age, gender, prediction, confidence, probabilities):

    pdf = FPDF()
    pdf.add_page()

    pdf.set_font("Arial", "B", 16)
    pdf.cell(0, 10, "AI Thyroid Diagnosis Report", ln=True, align="C")

    pdf.ln(10)

    pdf.set_font("Arial", size=12)

    pdf.cell(0, 10, f"Patient Name: {patient_name}", ln=True)
    pdf.cell(0, 10, f"Age: {age}", ln=True)
    pdf.cell(0, 10, f"Gender: {gender}", ln=True)
    pdf.cell(0, 10, f"Date: {datetime.now().strftime('%d-%m-%Y')}", ln=True)

    pdf.ln(10)

    pdf.cell(0, 10, "Prediction Result", ln=True)
    pdf.cell(0, 10, f"Class: {prediction}", ln=True)
    pdf.cell(0, 10, f"Confidence: {confidence:.2f}%", ln=True)

    pdf.ln(5)

    pdf.cell(0, 10, "Class Probabilities:", ln=True)

    for cls, prob in probabilities.items():
        pdf.cell(0, 10, f"{cls}: {prob:.2f}%", ln=True)

    pdf.ln(10)

    pdf.multi_cell(
        0,
        10,
        "Note: This AI generated report should be verified by a medical professional."
    )

    pdf.output("thyroid_report.pdf")

    print("Report Generated Successfully!")