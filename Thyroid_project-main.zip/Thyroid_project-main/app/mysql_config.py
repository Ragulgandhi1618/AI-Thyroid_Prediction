import mysql.connector
from mysql.connector import Error
from datetime import datetime

# ---------------- DATABASE CONNECTION ----------------
def get_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="thyroid_ai"
    )

# ---------------- LOG PREDICTION ----------------
def log_prediction(image_name, predicted_class, confidence, model_name="thyroid_inception_multiscale"):
    """
    Save prediction results to MySQL.
    """
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        # Create table if not exists (no timestamp column)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS prediction_results (
                id INT AUTO_INCREMENT PRIMARY KEY,
                image_name VARCHAR(255),
                predicted_class VARCHAR(50),
                confidence FLOAT,
                model_name VARCHAR(100)
            )
        """)
        
        # Insert prediction
        cursor.execute("""
            INSERT INTO prediction_results (image_name, predicted_class, confidence, model_name)
            VALUES (%s, %s, %s, %s)
        """, (image_name, predicted_class, confidence, model_name))
        
        conn.commit()
        cursor.close()
        conn.close()
        
    except Error as e:
        print(f"MySQL Error: {e}")

# ---------------- FETCH LAST 10 PREDICTIONS ----------------
def fetch_history():
    """
    Fetch last 10 predictions from MySQL.
    """
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT image_name, predicted_class, confidence, model_name
            FROM prediction_results
            ORDER BY id DESC
            LIMIT 10
        """)
        rows = cursor.fetchall()
        cursor.close()
        conn.close()
        return rows
    except Error as e:
        print(f"MySQL Error: {e}")
        return []