# ============================================
# PREPROCESS MODULE (PIPELINE + VISUALIZATION)
# ============================================

import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
import cv2
from tensorflow.keras.preprocessing.image import load_img, img_to_array

print("TensorFlow Version:", tf.__version__)
print("Preprocess Module Loaded Successfully")

IMG_HEIGHT, IMG_WIDTH = 256, 256


def preprocess_image(image_path, visualize=False):
    """
    Preprocess single image.
    If visualize=True → shows original & preprocessed image.
    Returns preprocessed image (model ready).
    """

    # Load and resize
    img = load_img(image_path, target_size=(IMG_HEIGHT, IMG_WIDTH))
    img_array = img_to_array(img) / 255.0

    # Convert to uint8 for OpenCV processing
    img_uint8 = (img_array * 255).astype(np.uint8)

    # Noise removal (your same logic)
    img_denoised = cv2.bilateralFilter(img_uint8, 9, 75, 75)

    # Contrast enhancement
    lab = cv2.cvtColor(img_denoised, cv2.COLOR_RGB2LAB)
    l, a, b = cv2.split(lab)
    l_eq = cv2.equalizeHist(l)
    lab_eq = cv2.merge((l_eq, a, b))
    enhanced = cv2.cvtColor(lab_eq, cv2.COLOR_LAB2RGB)

    enhanced = enhanced.astype(np.float32) / 255.0

    # Visualization (only if needed)
    if visualize:
        fig, axes = plt.subplots(1, 2, figsize=(10, 5))

        axes[0].imshow(img_array)
        axes[0].set_title("Original Image")
        axes[0].axis("off")

        axes[1].imshow(enhanced)
        axes[1].set_title("Preprocessed Image")
        axes[1].axis("off")

        plt.tight_layout()
        plt.show()

    # Expand dimension for model
    enhanced = np.expand_dims(enhanced, axis=0)

    return enhanced