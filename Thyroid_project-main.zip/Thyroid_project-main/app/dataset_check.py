import os
import cv2

# Base path to dataset
BASE_PATH = r"C:\Users\ELCOT\Desktop\project\Thyroid Classification Dataset1\Thyroid Classification Dataset1"

# Correct class names matching your folders
classes = ['benign','malignant','normal']

for cls in classes:
    folder = os.path.join(BASE_PATH, cls)
    if not os.path.exists(folder):
        print(f" Folder does not exist: {folder}")
        continue

    images = os.listdir(folder)
    print(f"{cls} folder has {len(images)} images")
    
    # Test reading the first image
    if images:
        img_path = os.path.join(folder, images[0])
        img = cv2.imread(img_path)
        if img is None:
            print(f" Error reading {img_path}")
        else:
            print(f" {img_path} loaded successfully, shape: {img.shape}")
    else:
        print(f" No images found in {folder}")