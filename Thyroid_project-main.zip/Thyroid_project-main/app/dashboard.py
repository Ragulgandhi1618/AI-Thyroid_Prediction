# ==========================================================
# PROFESSIONAL AI THYROID DIAGNOSIS DASHBOARD WITH MULTI-PAGE PDF
# ==========================================================

import streamlit as st
import pymysql
import pandas as pd
import numpy as np
import cv2
import tensorflow as tf
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
from PIL import Image
import os
from sklearn.metrics import confusion_matrix
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.utils import ImageReader
import io

# ================= CONFIG =================
MODEL_PATH = r"C:\Users\ELCOT\Desktop\project\saved_models\thyroid_inceptionv3_model.h5"
REPORTS_FOLDER = "reports"
os.makedirs(REPORTS_FOLDER, exist_ok=True)
class_labels = ['Malignant', 'benign', 'normal thyroid']

DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "root",
    "database": "thyroid_ai"
}

# ================= LOAD MODEL =================
@st.cache_resource
def load_thyroid_model():
    model = tf.keras.models.load_model(MODEL_PATH)
    return model

model = load_thyroid_model()

# ================= DATABASE FUNCTIONS =================
def get_connection():
    return pymysql.connect(**DB_CONFIG)

def save_prediction(image_name, predicted_class, confidence, stage):
    conn = get_connection()
    cursor = conn.cursor()
    query = """
    INSERT INTO prediction_results
    (image_name, predicted_class, confidence, clinical_stage, processed_at)
    VALUES (%s,%s,%s,%s,%s)
    """
    cursor.execute(query, (image_name, predicted_class, confidence, stage, datetime.now()))
    conn.commit()
    conn.close()

def load_data():
    conn = get_connection()
    df = pd.read_sql("SELECT * FROM prediction_results ORDER BY processed_at DESC", conn)
    conn.close()
    return df

# ================= PDF GENERATOR =================
def generate_professional_pdf(original_path, segmented_path, roi_path, predicted_class, confidence, stage, cm_fig, pie_fig, avg_conf, uploaded_file_name):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    pdf_path = os.path.join(REPORTS_FOLDER, f"thyroid_report_{timestamp}.pdf")
    c = canvas.Canvas(pdf_path, pagesize=A4)
    width, height = A4

    # ---------------- PAGE 1: Patient & Original Scan ----------------
    c.setFont("Helvetica-Bold", 22)
    c.drawString(50, height-50, "🩺 Thyroid Diagnosis Report")
    c.setFont("Helvetica", 14)
    c.drawString(50, height-90, f"Patient / File: {uploaded_file_name}")
    c.drawString(50, height-110, f"Report Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    c.drawString(50, height-140, "Original Ultrasound Scan:")
    img = Image.open(original_path)
    c.drawImage(ImageReader(original_path), 50, height-390, width=250, height=250)

    c.showPage()

    # ---------------- PAGE 2: Segmentation & ROI ----------------
    c.setFont("Helvetica-Bold", 20)
    c.drawString(50, height-50, "Segmentation & ROI Analysis")

    c.setFont("Helvetica", 14)
    c.drawString(50, height-80, f"Predicted Class: {predicted_class}")
    c.drawString(50, height-100, f"Confidence: {confidence:.2f}%")
    c.drawString(50, height-120, f"Clinical Stage: {stage}")

    c.drawString(50, height-150, "Segmented Image:")
    c.drawImage(ImageReader(segmented_path), 50, height-400, width=250, height=250)

    c.drawString(320, height-150, "ROI Extracted:")
    c.drawImage(ImageReader(roi_path), 320, height-400, width=250, height=250)

    c.showPage()

    # ---------------- PAGE 3: Analytics ----------------
    c.setFont("Helvetica-Bold", 20)
    c.drawString(50, height-50, "Analytics & AI Metrics")

    c.setFont("Helvetica", 14)
    c.drawString(50, height-80, f"Average AI Confidence: {avg_conf:.2f}%")

    # Confusion Matrix
    buf_cm = io.BytesIO()
    cm_fig.savefig(buf_cm, format="PNG", bbox_inches="tight")
    buf_cm.seek(0)
    c.drawString(50, height-120, "Confusion Matrix:")
    c.drawImage(ImageReader(buf_cm), 50, height-420, width=250, height=250)

    # Pie Chart
    buf_pie = io.BytesIO()
    pie_fig.savefig(buf_pie, format="PNG", bbox_inches="tight")
    buf_pie.seek(0)
    c.drawString(320, height-120, "Prediction Distribution:")
    c.drawImage(ImageReader(buf_pie), 320, height-420, width=250, height=250)

    c.showPage()
    c.save()
    return pdf_path

# ================= STREAMLIT UI =================
st.set_page_config(page_title="AI Thyroid Diagnosis System", layout="wide")
st.title("🩺 AI Thyroid Diagnosis System")
st.markdown("Upload an ultrasound image to detect thyroid condition using AI")

uploaded_file = st.file_uploader("Upload Thyroid Ultrasound Image", type=["jpg","jpeg","png"])

if uploaded_file:
    file_bytes = np.asarray(bytearray(uploaded_file.read()), dtype=np.uint8)
    image = cv2.imdecode(file_bytes, 1)
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    st.image(image_rgb, caption="Uploaded Ultrasound Image", width=400)

    if st.button("Run AI Diagnosis"):
        # ---------------- SEGMENTATION ----------------
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        blur = cv2.GaussianBlur(gray, (5,5), 0)
        _, mask = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        segmented = cv2.bitwise_and(image_rgb, image_rgb, mask=mask)
        st.image(segmented, caption="Segmented Image", width=400)

        # ---------------- ROI EXTRACTION ----------------
        contours,_ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if contours:
            c = max(contours, key=cv2.contourArea)
            x,y,w,h = cv2.boundingRect(c)
            roi = image_rgb[y:y+h, x:x+w]
        else:
            roi = image_rgb
        roi_resized = cv2.resize(roi, (224,224))
        st.image(roi, caption="ROI Extracted", width=300)

        # ---------------- CLASSIFICATION ----------------
        input_img = np.expand_dims(roi_resized.astype(np.float32)/255.0, axis=0)
        preds = model.predict(input_img)
        pred_index = np.argmax(preds)
        predicted_class = class_labels[pred_index]
        confidence = float(np.max(preds))*100
        stage = "Cancer Risk (Malignant Nodule)" if predicted_class=="Malignant" else \
                "Benign Thyroid Nodule" if predicted_class=="benign" else "Normal Thyroid Tissue"

        st.success("Diagnosis Completed")
        col1,col2,col3 = st.columns(3)
        col1.metric("Prediction", predicted_class)
        col2.metric("Confidence", f"{confidence:.2f}%")
        col3.metric("Clinical Stage", stage)

        # ---------------- SAVE PREDICTION ----------------
        save_prediction(uploaded_file.name, predicted_class, confidence, stage)
        original_path = os.path.join(REPORTS_FOLDER, f"original_{uploaded_file.name}")
        segmented_path = os.path.join(REPORTS_FOLDER, f"segmented_{uploaded_file.name}")
        roi_path = os.path.join(REPORTS_FOLDER, f"roi_{uploaded_file.name}")
        cv2.imwrite(original_path, cv2.cvtColor(image_rgb, cv2.COLOR_RGB2BGR))
        cv2.imwrite(segmented_path, cv2.cvtColor(segmented, cv2.COLOR_RGB2BGR))
        cv2.imwrite(roi_path, cv2.cvtColor(roi, cv2.COLOR_RGB2BGR))

        # ---------------- DASHBOARD DATA ----------------
        data = load_data()
        total_scans = len(data)
        malignant = len(data[data["predicted_class"]=="Malignant"])
        benign = len(data[data["predicted_class"]=="benign"])
        normal = len(data[data["predicted_class"]=="normal thyroid"])
        avg_conf = data['confidence'].mean() if total_scans>0 else 0

        # Pie Chart
        fig_pie, ax_pie = plt.subplots()
        ax_pie.pie([malignant, benign, normal], labels=["Malignant","Benign","Normal"], autopct='%1.1f%%', startangle=90)
        st.pyplot(fig_pie)

        # Confusion Matrix
        data_filtered = data.copy()
        data_filtered["actual_class"] = data_filtered["clinical_stage"].replace({
            "Cancer Risk (Malignant Nodule)":"Malignant",
            "Benign Thyroid Nodule":"benign",
            "Normal Thyroid Tissue":"normal thyroid"
        })
        data_filtered = data_filtered[
            data_filtered["actual_class"].isin(class_labels) &
            data_filtered["predicted_class"].isin(class_labels)
        ]
        if len(data_filtered) > 0:
            cm = confusion_matrix(data_filtered["actual_class"], data_filtered["predicted_class"], labels=class_labels)
            fig_cm, ax_cm = plt.subplots()
            sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", 
                        xticklabels=class_labels, yticklabels=class_labels, ax=ax_cm)
            ax_cm.set_xlabel("Predicted")
            ax_cm.set_ylabel("Actual")
            st.pyplot(fig_cm)
            
        else:
            fig_cm, ax_cm = plt.subplots()

        # ---------------- GENERATE PROFESSIONAL PDF ----------------
        pdf_file = generate_professional_pdf(
            original_path, segmented_path, roi_path,
            predicted_class, confidence, stage,
            fig_cm, fig_pie, avg_conf,
            uploaded_file.name
        )
        st.success(f" Professional PDF Report Generated: `{pdf_file}`")
        with open(pdf_file, "rb") as f:
            st.download_button("Download PDF Report", f, file_name=os.path.basename(pdf_file))