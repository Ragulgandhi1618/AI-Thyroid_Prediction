import os
import cv2
import numpy as np
import random
import tensorflow as tf

# ================= PATHS =================
MODEL_PATH = r"C:\Users\ELCOT\Desktop\project\saved_models\thyroid_inception_multiscale.h5"
DATASET_PATH = r"C:\Users\ELCOT\Desktop\project\Thyroid Classification Dataset1\Thyroid Classification Dataset1"

class_labels = ['benign', 'malignant', 'normal']

# ================= LOAD MODEL =================
print("Loading Model...")
model = tf.keras.models.load_model(MODEL_PATH)
print("Model Loaded Successfully\n")

# ================= HELPER FUNCTION =================
def predict_image(image_path):
    img = cv2.imread(image_path)
    if img is None:
        print(f" Could not read {image_path}")
        return None
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    
    # Optional: Resize and normalize
    roi = cv2.resize(img_rgb, (224,224))
    input_img = roi.astype(np.float32)/255.0
    input_img = np.expand_dims(input_img, axis=0)
    
    preds = model.predict(input_img)
    pred_index = np.argmax(preds)
    predicted_class = class_labels[pred_index]
    confidence = float(np.max(preds))*100
    return predicted_class, confidence

# ================= TEST RANDOM IMAGES =================
for cls in class_labels:
    folder = os.path.join(DATASET_PATH, cls)
    if not os.path.exists(folder):
        print(f" Folder not found: {folder}")
        continue

    images = os.listdir(folder)
    if not images:
        print(f" No images in folder: {folder}")
        continue
    
    # Randomly select 3 images (or all if less than 3)
    sample_images = random.sample(images, min(3, len(images)))
    
    print(f"\nTesting class: {cls} ({len(images)} images, showing {len(sample_images)} samples)")
    
    for img_name in sample_images:
        img_path = os.path.join(folder, img_name)
        predicted_class, confidence = predict_image(img_path)
        print(f"Image: {img_name} | Actual: {cls} | Predicted: {predicted_class} | Confidence: {confidence:.2f}%")