import streamlit as st
import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
from datetime import datetime

# --- REPORTLAB FIXES ---
from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
# Fix for the "ImportError: cannot import name 'Drawing' from 'reportlab.platypus'"
from reportlab.graphics.shapes import Drawing 

# --- DATABASE FIXES ---
# Note: Ensure your database table has 'gender', 'age', and 'patient_name' columns.
# Mocking get_connection for the example - replace with your actual pymysql logic
def get_connection():
    try:
        import pymysql
        # Replace with your actual credentials
        return pymysql.connect(host='localhost', user='root', password='', db='medical_db')
    except:
        return None

# UI CONFIGURATION
st.set_page_config(page_title="Med-AI Diagnostics Pro", page_icon="🏥", layout="wide")

# Custom CSS for a Premium Medical Look
st.markdown("""
    <style>
    .main { background-color: #f8f9fa; }
    .stButton>button {
        width: 100%;
        border-radius: 10px;
        height: 3em;
        background-color: #007bff;
        color: white;
        font-weight: bold;
        border: none;
    }
    .metric-card {
        background-color: white;
        padding: 20px;
        border-radius: 15px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        border-left: 5px solid #007bff;
    }
    .patient-header {
        background: linear-gradient(90deg, #007bff 0%, #00d4ff 100%);
        color: white;
        padding: 2rem;
        border-radius: 15px;
        margin-bottom: 2rem;
    }
    .gender-icon {
        font-size: 40px;
        margin-right: 15px;
    }
    </style>
""", unsafe_allow_html=True)

def generate_pdf(predicted_class, confidence, stage, name, age, gender, preds, class_labels, folder):
    if not os.path.exists(folder):
        os.makedirs(folder)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = os.path.join(folder, f"Report_{name}_{timestamp}.pdf")
    
    doc = SimpleDocTemplate(filename, pagesize=A4, rightMargin=50, leftMargin=50, topMargin=50, bottomMargin=50)
    styles = getSampleStyleSheet()
    story = []

    # Title
    title_style = ParagraphStyle('TitleStyle', parent=styles['Heading1'], alignment=1, spaceAfter=20, textColor=colors.dodgerblue)
    story.append(Paragraph("MEDICAL DIAGNOSTIC REPORT", title_style))
    story.append(Spacer(1, 12))

    # Patient Info Table
    data = [
        ['Patient Name:', name, 'Age:', str(age)],
        ['Gender:', gender, 'Date:', datetime.now().strftime("%Y-%m-%d")],
        ['Diagnosis:', predicted_class, 'Confidence:', f"{confidence:.2f}%"]
    ]
    t = Table(data, colWidths=[1.2*inch, 2*inch, 1*inch, 2*inch])
    t.setStyle(TableStyle([
        ('GRID', (0,0), (-1,-1), 0.5, colors.grey),
        ('BACKGROUND', (0,0), (0,-1), colors.whitesmoke),
        ('BACKGROUND', (2,0), (2,-1), colors.whitesmoke),
        ('PADDING', (0,0), (-1,-1), 6),
    ]))
    story.append(t)
    story.append(Spacer(1, 24))

    # Summary
    story.append(Paragraph(f"Analysis Summary:", styles['Heading2']))
    story.append(Paragraph(f"The automated AI system has identified the condition as <b>{predicted_class}</b> with a confidence level of {confidence:.2f}%. Clinical correlation is recommended.", styles['Normal']))
    
    doc.build(story)
    return filename

# --- MAIN APP LOGIC ---

if 'user_info' not in st.session_state:
    st.session_state.user_info = {'patient_id': 1, 'name': 'John Doe', 'age': 45, 'gender': 'Male'}

# UI Header
with st.container():
    u = st.session_state.user_info
    g_icon = "👨" if u['gender'] == 'Male' else "👩"
    st.markdown(f"""
        <div class="patient-header">
            <div style="display: flex; align-items: center;">
                <span class="gender-icon">{g_icon}</span>
                <div>
                    <h1 style="margin:0;">{u['name']}</h1>
                    <p style="margin:0; opacity: 0.9;">Patient ID: {u['patient_id']} | {u['age']} Years | {u['gender']}</p>
                </div>
            </div>
        </div>
    """, unsafe_allow_html=True)

# Sidebar Features
with st.sidebar:
    st.image("https://cdn-icons-png.flaticon.com/512/387/387561.png", width=100)
    st.title("Settings")
    theme = st.selectbox("UI Theme", ["Modern Blue", "Clinical White", "Dark Mode"])
    st.divider()
    st.info("AI Model: v2.4.0-Stable\nLast Updated: Oct 2023")

# Main Dashboard Tabs
tab1, tab2, tab3 = st.tabs(["🔍 Diagnostics", "📊 History", "📋 Health Profile"])

with tab1:
    col1, col2 = st.columns([1, 1])
    with col1:
        st.subheader("Upload Scan")
        uploaded_file = st.file_uploader("Choose an image...", type=["jpg", "png", "jpeg"])
        if uploaded_file:
            st.image(uploaded_file, use_container_width=True, caption="Uploaded Scan")
    
    with col2:
        st.subheader("Analysis Results")
        if uploaded_file:
            # Simulated Prediction
            predicted_class = "Healthy"
            confidence = 98.5
            
            st.markdown(f"""
                <div class="metric-card">
                    <small>PREDICTED CONDITION</small>
                    <h2 style="color:#28a745;">{predicted_class}</h2>
                    <hr>
                    <small>AI CONFIDENCE</small>
                    <h2 style="color:#007bff;">{confidence}%</h2>
                </div>
            """, unsafe_allow_html=True)
            
            if st.button("Generate Medical Report"):
                with st.spinner("Preparing PDF..."):
                    path = generate_pdf(predicted_class, confidence, "N/A", u['name'], u['age'], u['gender'], [0.98, 0.02], ["Healthy", "Pathology"], "reports")
                    st.success("Report generated successfully!")
                    with open(path, "rb") as f:
                        st.download_button("Download PDF", f, file_name=os.path.basename(path))

with tab2:
    st.subheader("Diagnostic History")
    conn = get_connection()
    if conn:
        try:
            # FIX: Changed 'Confidence %' to 'Confidence_Pct' to avoid the 0x27 character error in pymysql
            # FIX: Using patient_id=%s with a tuple to prevent injection and formatting errors
            query = """
                SELECT 
                    timestamp as 'Date', 
                    predicted_class as 'Diagnosis', 
                    confidence as 'Confidence_Score' 
                FROM prediction_results 
                WHERE patient_id = %s 
                ORDER BY timestamp DESC
            """
            history = pd.read_sql(query, conn, params=(st.session_state.user_info['patient_id'],))
            st.dataframe(history, use_container_width=True)
        except Exception as e:
            st.error(f"Database Error: {e}")
            st.info("Ensure column names match: 'timestamp', 'predicted_class', 'confidence', 'patient_id'")
        finally:
            conn.close()
    else:
        st.warning("Database connection unavailable. Showing demo data.")
        demo_data = pd.DataFrame({
            'Date': [datetime.now().date()],
            'Diagnosis': ['Healthy'],
            'Confidence_Score': [98.5]
        })
        st.table(demo_data)

with tab3:
    st.subheader("Comprehensive Profile")
    c1, c2, c3 = st.columns(3)
    c1.metric("Vitals Score", "94/100", "+2%")
    c2.metric("Last Visit", "12 Days ago")
    c3.metric("Risk Factor", "Low", border=True)
    
    st.progress(0.85, "Overall Health Index")

# FIXING THE INSERT QUERY ERROR
# If you are getting "Unknown column 'name'", ensure your table matches these fields:
def save_prediction(patient_id, p_class, p_conf):
    conn = get_connection()
    if conn:
        cursor = conn.cursor()
        try:
            # Ensure these columns exist in your MySQL table
            # Check if you intended to use 'patient_id' instead of 'name'
            sql = "INSERT INTO prediction_results (patient_id, predicted_class, confidence, timestamp) VALUES (%s, %s, %s, %s)"
            cursor.execute(sql, (patient_id, p_class, p_conf, datetime.now()))
            conn.commit()
        except Exception as e:
            st.error(f"Save Failed: {e}")
        finally:
            conn.close()