import os
import pymysql
from datetime import datetime

# ================= MySQL CONFIG =================
host = "localhost"
user = "root"
password = "root"         # replace with your MySQL password
database = "thyroid_ai"

# ================= DATASET CONFIG =================
BASE_PATH = r"C:\Users\ELCOT\Desktop\project"
DATASET_PATH = os.path.join(BASE_PATH, "Thyroid Classification Dataset1", "Thyroid Classification Dataset1")

# ================= MODEL CONFIG =================
MODEL_NAME = "InceptionV3"
MODEL_VERSION = "1.0"
SEGMENTATION_USED = 1  # 1=True, 0=False

# ================= CONNECT TO MYSQL =================
conn = pymysql.connect(host=host, user=user, password=password, database=database)
cursor = conn.cursor()

# ================= LOOP THROUGH IMAGES =================
for root, dirs, files in os.walk(DATASET_PATH):
    for file in files:
        if file.lower().endswith((".jpg", ".jpeg", ".png")):
            image_path = os.path.join(root, file)
            image_name = file
            predicted_class = os.path.basename(os.path.dirname(image_path))  # folder name as class
            confidence = 0  # can update later after classification
            patient_id = "Unknown"  # can update later if known
            scan_date = datetime.today().strftime("%Y-%m-%d")

            # ================= INSERT INTO TABLE =================
            sql = """
            INSERT INTO prediction_results
            (image_name, predicted_class, confidence, model_name, model_version,
             segmentation_used, patient_id, scan_date, image_path)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            values = (image_name, predicted_class, confidence, MODEL_NAME, MODEL_VERSION,
                      SEGMENTATION_USED, patient_id, scan_date, image_path)
            cursor.execute(sql, values)

# ================= COMMIT AND CLOSE =================
conn.commit()
cursor.close()
conn.close()
print("All images inserted into prediction_results successfully!")