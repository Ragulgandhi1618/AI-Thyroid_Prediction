# classification.py

import os
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.models import load_model
from sklearn.metrics import classification_report, roc_auc_score, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
from glob import glob
from tensorflow.keras.applications.inception_v3 import InceptionV3
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D
from tensorflow.keras.models import Model

# ================== CONFIG ==================
DATASET_FOLDER = r"C:\Users\ELCOT\Desktop\project\Thyroid Classification Dataset1\Thyroid Classification Dataset1"
IMG_SIZE = 224
BATCH_SIZE = 16
EPOCHS = 10

# ================== MODEL ==================
def build_model(num_classes):
    base_model = InceptionV3(weights='imagenet', include_top=False, input_shape=(IMG_SIZE, IMG_SIZE, 3))
    x = base_model.output
    x = GlobalAveragePooling2D()(x)
    x = Dense(1024, activation='relu')(x)
    predictions = Dense(num_classes, activation='softmax')(x)
    model = Model(inputs=base_model.input, outputs=predictions)
    
    # Compile with metrics
    model.compile(
        optimizer='adam',
        loss='categorical_crossentropy',
        metrics=['accuracy', tf.keras.metrics.Precision(), tf.keras.metrics.Recall()]
    )
    return model

# ================== LOAD DATA ==================
datagen = ImageDataGenerator(rescale=1./255, validation_split=0.2)

train_gen = datagen.flow_from_directory(
    DATASET_FOLDER,
    target_size=(IMG_SIZE, IMG_SIZE),
    batch_size=BATCH_SIZE,
    class_mode="categorical",
    subset="training"
)

val_gen = datagen.flow_from_directory(
    DATASET_FOLDER,
    target_size=(IMG_SIZE, IMG_SIZE),
    batch_size=BATCH_SIZE,
    class_mode="categorical",
    subset="validation",
    shuffle=False
)

class_labels = list(train_gen.class_indices.keys())
num_classes = len(class_labels)

# ================== BUILD OR LOAD MODEL ==================
model_path = "thyroid_model.h5"
if os.path.exists(model_path):
    model = load_model(model_path)
    print("Loaded existing model.")
else:
    model = build_model(num_classes)
    print("Built new model.")
    model.summary()

# ================== TRAIN MODEL ==================
if not os.path.exists(model_path):
    print("\nTraining model...")
    history = model.fit(train_gen, validation_data=val_gen, epochs=EPOCHS)
    model.save(model_path)
    print(f"Model saved to {model_path}")
else:
    print("\nSkipping training (model already exists).")

# ================== EVALUATE PERFORMANCE ==================
def evaluate_performance():
    print("\nEvaluating performance on validation dataset...")
    
    # Predictions
    y_true = val_gen.classes
    y_pred_probs = model.predict(val_gen)
    y_pred = np.argmax(y_pred_probs, axis=1)
    
    # Metrics
    print("\n========== MODEL PERFORMANCE ==========")
    print(f"Accuracy: {np.mean(y_pred == y_true)*100:.2f}%")
    print("\nClassification Report:\n")
    print(classification_report(y_true, y_pred, target_names=class_labels))
    
    # AUC
    try:
        y_true_onehot = tf.keras.utils.to_categorical(y_true, num_classes=num_classes)
        auc = roc_auc_score(y_true_onehot, y_pred_probs, multi_class="ovr")
        print(f"AUC Score: {auc*100:.2f}%")
    except:
        print("AUC Score: Could not compute (check labels)")
    
    # Confusion Matrix
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(6,5))
    sns.heatmap(cm, annot=True, fmt="d", xticklabels=class_labels, yticklabels=class_labels, cmap="Blues")
    plt.xlabel("Predicted")
    plt.ylabel("True")
    plt.title("Confusion Matrix")
    plt.show()
    print("=======================================")

# ================== PREDICT IMAGE ==================
def predict_image(image_path):
    img = tf.keras.utils.load_img(image_path, target_size=(IMG_SIZE, IMG_SIZE))
    img_array = tf.keras.utils.img_to_array(img)/255.0
    img_array = np.expand_dims(img_array, axis=0)
    preds = model.predict(img_array)[0]
    
    confidence = np.max(preds)*100
    predicted_class = class_labels[np.argmax(preds)]
    class_probs = [f"{cls}: {p*100:.2f}%" for cls, p in zip(class_labels, preds)]
    
    print("\n========== IMAGE PREDICTION ==========")
    print(f"Predicted Class : {predicted_class}")
    print(f"Confidence      : {confidence:.2f}%")
    print(f"Class Probabilities: {class_probs}")
    print("=======================================")

# ================== MAIN ==================
if __name__ == "__main__":
    print("Choose mode:\n1. Manual Image Prediction\n2. Automatic (pick random image from dataset)")
    choice = input("Enter choice (1 or 2): ").strip()
    
    if choice == "1":
        image_path = input("Enter full path of the image: ").strip()
        if os.path.exists(image_path):
            predict_image(image_path)
        else:
            print("Image path not found!")
    elif choice == "2":
        # Pick a random image automatically
        all_images = glob(os.path.join(DATASET_FOLDER, "*", "*.*"))
        if len(all_images) == 0:
            print("No images found in dataset!")
        else:
            random_img = np.random.choice(all_images)
            print("Randomly selected image:", random_img)
            predict_image(random_img)
    else:
        print("Invalid choice!")
    
    # Evaluate performance
    evaluate_performance()
# # ==========================================================
# # THYROID CLASSIFICATION MODULE (Without Grad-CAM)
# # ==========================================================

# import numpy as np
# import cv2
# from tensorflow.keras.preprocessing import image
# from tensorflow.keras.models import load_model

# # ----------------- CONFIG -----------------
# IMG_SIZE = 256  # Input size for your model
# MODEL_PATH = "saved_models/thyroid_inception_multiscale.h5"
# class_labels = ['benign', 'malignant', 'normal thyroid']

# # ---------------- LOAD MODEL ----------------
# print("\n========== THYROID CLASSIFICATION MODULE ==========")
# print(f"Loading model from: {MODEL_PATH}")
# model = load_model(MODEL_PATH)
# print("Model Loaded Successfully")
# print(f"Class Labels: {class_labels}\n")

# # ----------------- PREPROCESS IMAGE -----------------
# def preprocess_image(img_input):
#     """
#     Preprocess ROI image for prediction.
#     img_input: numpy array (H, W, C) or image path
#     Returns: np.array of shape (1, IMG_SIZE, IMG_SIZE, 3)
#     """
#     if isinstance(img_input, str):
#         # Load from file path
#         img_array = image.img_to_array(
#             image.load_img(img_input, target_size=(IMG_SIZE, IMG_SIZE))
#         )
#     elif isinstance(img_input, np.ndarray):
#         # Resize ROI numpy array
#         img_array = cv2.resize(img_input, (IMG_SIZE, IMG_SIZE))
#     else:
#         raise TypeError(f"Unsupported type {type(img_input)} for preprocessing")
    
#     img_array = img_array / 255.0  # normalize
#     img_array = np.expand_dims(img_array, axis=0)
#     return img_array

# # ----------------- PREDICT IMAGE -----------------
# def predict_image(img_input):
#     """
#     img_input: numpy array ROI image or image path
#     Returns: predicted_class (str), confidence (float), class_probs (np.array)
#     """
#     img_array = preprocess_image(img_input)
    
#     # Ensure model layers are initialized
#     _ = model.predict(img_array)
    
#     preds = model.predict(img_array)
#     class_idx = np.argmax(preds[0])
#     predicted_class = class_labels[class_idx]
#     confidence = float(preds[0][class_idx])
    
#     return predicted_class, confidence, preds[0]



# ==========================================================
# # classification.py
# # ==========================================================

# import os
# import numpy as np
# import cv2
# from tensorflow.keras.models import load_model
# from tensorflow.keras.preprocessing import image

# # ================= CONFIG =================
# IMG_SIZE = 224  # Inception-based models usually expect 224x224
# MODEL_PATH = os.path.join("saved_models", "thyroid_inception_multiscale.h5")
# class_labels = ['benign', 'malignant', 'normal thyroid']

# # ================= LOAD MODEL =================
# print("\n========== THYROID CLASSIFICATION MODULE ==========")
# print("Loading model from:", MODEL_PATH)
# model = load_model(MODEL_PATH)
# print("Model Loaded Successfully")
# print("Class Labels:", class_labels)

# # ==========================================================
# # IMAGE PREPROCESSING
# # ==========================================================
# def preprocess_image(img_input):
#     """
#     Accepts:
#         - img_input: path (str) OR numpy array (from segmentation/ROI)
#     Returns:
#         - 4D numpy array for model input: (1, IMG_SIZE, IMG_SIZE, 3)
#     """
#     if isinstance(img_input, np.ndarray):
#         # Resize ROI image
#         img_array = cv2.resize(img_input, (IMG_SIZE, IMG_SIZE))
#         img_array = img_array.astype(np.float32) / 255.0
#     elif isinstance(img_input, str):
#         img = image.load_img(img_input, target_size=(IMG_SIZE, IMG_SIZE))
#         img_array = image.img_to_array(img) / 255.0
#     else:
#         raise TypeError("Input must be path (str) or np.ndarray")

#     # Ensure shape is (1, H, W, C)
#     if img_array.ndim == 3:
#         img_array = np.expand_dims(img_array, axis=0)

#     return img_array

# # ==========================================================
# # PREDICTION FUNCTION
# # ==========================================================
# def predict_image(img_input):
#     """
#     Predict thyroid class for an input image.
    
#     Args:
#         img_input: path (str) or numpy array (ROI)
#     Returns:
#         predicted_class (str), confidence (float), all class probabilities (numpy array)
#     """
#     img_array = preprocess_image(img_input)
#     preds = model.predict(img_array)
#     class_idx = np.argmax(preds[0])
#     predicted_class = class_labels[class_idx]
#     confidence = float(preds[0][class_idx])
#     return predicted_class, confidence, preds[0]

# # ==========================================================
# # TESTING (Optional)
# # ==========================================================
# if __name__ == "__main__":
#     test_path = "ROI_256x256_Output/0516.jpg"
#     if os.path.exists(test_path):
#         pred_class, conf, probs = predict_image(test_path)
#         print("Predicted Class:", pred_class)
#         print("Confidence:", conf)
#         print("Probabilities:", probs)
#     else:
#         print("Test image not found:", test_path)# 








# # ==========================================================
# # THYROID CLASSIFICATION MODULE
# # ==========================================================

# import numpy as np
# from tensorflow.keras.models import load_model
# from tensorflow.keras.preprocessing import image
# import cv2
# import os

# # ================= CONFIG =================
# IMG_SIZE = 256  # Segmented ROI is 256x256
# MODEL_PATH = os.path.join("saved_models", "thyroid_inception_multiscale.h5")
# class_labels = ['benign', 'malignant', 'normal thyroid']

# # ================= LOAD MODEL =================
# print("\n========== THYROID CLASSIFICATION MODULE ==========")
# print("Loading model from:", MODEL_PATH)
# model = load_model(MODEL_PATH)
# print("Model Loaded Successfully")
# print("Class Labels:", class_labels)


# # ==========================================================
# # IMAGE PREPROCESSING
# # ==========================================================
# def preprocess_image(img_input):
#     """
#     Accepts either:
#         - img_input: path (str)
#         - img_input: numpy array (from segmentation output)
#     Returns: flattened array with batch dimension (1, 256*256*3)
#     """
#     if isinstance(img_input, np.ndarray):
#         img_array = cv2.resize(img_input, (IMG_SIZE, IMG_SIZE))
#         img_array = img_array.astype(np.float32) / 255.0
#     elif isinstance(img_input, str):
#         img = image.load_img(img_input, target_size=(IMG_SIZE, IMG_SIZE))
#         img_array = image.img_to_array(img) / 255.0
#     else:
#         raise TypeError("Input must be path (str) or np.ndarray")

#     # Flatten to match model input
#     img_array = img_array.flatten()
#     img_array = np.expand_dims(img_array, axis=0)
#     return img_array


# # ==========================================================
# # PREDICTION FUNCTION
# # ==========================================================
# def predict_image(img_input):
#     """
#     Returns:
#         - predicted_class (str)
#         - confidence (float)
#         - all class probabilities (numpy array)
#     """
#     img_array = preprocess_image(img_input)
#     preds = model.predict(img_array)
#     class_idx = np.argmax(preds[0])
#     predicted_class = class_labels[class_idx]
#     confidence = float(preds[0][class_idx])
#     return predicted_class, confidence, preds[0]


# # ==========================================================
# # TESTING (Optional)
# # ==========================================================
# if __name__ == "__main__":
#     test_path = "ROI_256x256_Output/0516.jpg"
#     if os.path.exists(test_path):
#         pred_class, conf, probs = predict_image(test_path)
#         print("Predicted Class:", pred_class)
#         print("Confidence:", conf)
#         print("Probabilities:", probs)
#     else:
#         print("Test image not found:", test_path)







# # ==========================================================
# # CLASSIFICATION MODULE (PIPELINE + STREAMLIT READY)
# # ==========================================================

# import numpy as np
# import cv2
# import tensorflow as tf
# from tensorflow.keras.models import load_model

# # -----------------------------
# # Model Path & Load
# # -----------------------------
# MODEL_PATH = r"saved_models/thyroid_inception_multiscale.h5"
# print(f"\n========== THYROID CLASSIFICATION MODULE ==========")
# print(f"Loading model from: {MODEL_PATH}")
# model = load_model(MODEL_PATH)
# print("Model Loaded Successfully")

# # -----------------------------
# # Class Labels
# # -----------------------------
# class_labels = ['benign', 'malignant', 'normal thyroid']
# print("Class Labels:", class_labels)

# # -----------------------------
# # Image Size
# # -----------------------------
# IMG_SIZE = 256  # Adjust if your model uses a different size

# # ==========================================================
# # IMAGE PREPROCESSING FUNCTION
# # ==========================================================
# def preprocess_image(img_input):
#     """
#     Accepts either:
#     - file path (str)
#     - numpy array (H x W x 3)
#     Returns preprocessed numpy array for model prediction
#     """

#     if isinstance(img_input, str):
#         # Load from file
#         from tensorflow.keras.preprocessing import image
#         img = image.load_img(img_input, target_size=(IMG_SIZE, IMG_SIZE))
#         img_array = image.img_to_array(img) / 255.0

#     elif isinstance(img_input, np.ndarray):
#         # Already a numpy array
#         img_array = cv2.resize(img_input, (IMG_SIZE, IMG_SIZE))
#         img_array = img_array.astype(np.float32) / 255.0

#     else:
#         raise TypeError("Input should be file path or numpy array")

#     # Expand dims for batch
#     img_array = np.expand_dims(img_array, axis=0)
#     return img_array

# # ==========================================================
# # PREDICTION FUNCTION
# # ==========================================================
# def predict_image(img_input):
#     """
#     Takes either a file path or numpy array (ROI image)
#     Returns:
#         - predicted_class (str)
#         - confidence (float)
#         - probabilities (numpy array)
#     """

#     img_array = preprocess_image(img_input)
#     preds = model.predict(img_array)

#     class_idx = np.argmax(preds[0])
#     predicted_class = class_labels[class_idx]
#     confidence = float(preds[0][class_idx])
#     probs = preds[0]

#     return predicted_class, confidence, probs

# # ==========================================================
# # GRADCAM INTEGRATION HELPER
# # ==========================================================
# def get_model_layers():
#     """Return model layers for GradCAM"""
#     return [layer.name for layer in model.layers]

# def get_last_conv_layer():
#     """Auto detect last convolution layer for GradCAM"""
#     for layer in reversed(model.layers):
#         if len(layer.output.shape) == 4:
#             return layer.name
#     raise ValueError("No convolution layer found in model")





# # ==========================================================
# # THYROID IMAGE CLASSIFICATION (PROFESSIONAL OUTPUT)
# # InceptionV3 Model - With Visualization
# # ==========================================================

# import os
# import numpy as np
# import tensorflow as tf
# import matplotlib.pyplot as plt
# from tensorflow.keras.models import load_model
# from tensorflow.keras.preprocessing import image
# from tensorflow.keras.applications.inception_v3 import preprocess_input

# print("\n========== THYROID CLASSIFICATION MODULE ==========\n")

# # ==========================================================
# # PATH SETUP
# # ==========================================================

# BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# PROJECT_ROOT = os.path.abspath(os.path.join(BASE_DIR, ".."))

# MODEL_PATH = os.path.join(
#     PROJECT_ROOT,
#     "saved_models",
#     "thyroid_inception_multiscale.h5"
# )

# DATASET_PATH = os.path.join(
#     PROJECT_ROOT,
#     "Thyroid Classification Dataset1",
#     "Thyroid Classification Dataset1"
# )

# IMG_SIZE = 224

# # ==========================================================
# # LOAD MODEL
# # ==========================================================

# print("Loading model from:", MODEL_PATH)

# model = load_model(MODEL_PATH)

# print("Model Loaded Successfully")

# # ==========================================================
# # IMPORTANT: CLASS LABEL ORDER (must match training order)
# # ==========================================================

# class_labels = [
#     "benign",
#     "malignant",
#     "normal thyroid"
# ]

# print("Class Labels:", class_labels)

# # ==========================================================
# # THYROID STAGE DESCRIPTION
# # ==========================================================

# stage_description = {
#     "normal thyroid": "Healthy thyroid gland. No abnormal nodules detected.",
#     "benign": "Non-cancerous thyroid nodule detected. Usually slow growing.",
#     "malignant": "Cancerous thyroid nodule detected. Requires medical evaluation."
# }

# # ==========================================================
# # IMAGE PREPROCESSING
# # ==========================================================

# def preprocess_image(img_path):

#     img = image.load_img(img_path, target_size=(IMG_SIZE, IMG_SIZE))
#     img_array = image.img_to_array(img)

#     img_array = np.expand_dims(img_array, axis=0)
#     img_array = preprocess_input(img_array)

#     return img_array


# # ==========================================================
# # PROFESSIONAL VISUAL OUTPUT
# # ==========================================================

# def show_results(original_path, predicted_class, confidence):

#     original = image.load_img(original_path)

#     description = stage_description.get(predicted_class, "Unknown stage")

#     plt.figure(figsize=(8,5))

#     plt.imshow(original)
#     plt.title("Ultrasound Scan")
#     plt.axis("off")

#     plt.suptitle(
#         f"Prediction: {predicted_class} | Confidence: {round(confidence*100,2)}%",
#         fontsize=14,
#         fontweight="bold"
#     )

#     plt.figtext(
#         0.5,
#         0.01,
#         f"Stage Information: {description}",
#         wrap=True,
#         horizontalalignment='center',
#         fontsize=11
#     )

#     plt.tight_layout()
#     plt.show()


# # ==========================================================
# # PREDICTION FUNCTION
# # ==========================================================

# def predict_image(img_path):

#     img_array = preprocess_image(img_path)

#     prediction = model.predict(img_array)

#     predicted_index = np.argmax(prediction)
#     confidence = float(np.max(prediction))
#     predicted_class = class_labels[predicted_index]

#     print("\n========== AI DIAGNOSIS REPORT ==========")

#     print("\nDetected Condition :", predicted_class.upper())
#     print("Confidence Level   :", round(confidence*100,2), "%")

#     print("\n------ Probability Breakdown ------")

#     for i, label in enumerate(class_labels):
#         prob = prediction[0][i] * 100
#         print(f"{label:<15} : {prob:.2f}%")

#     print("------------------------------------")

#     show_results(img_path, predicted_class, confidence)

#     return predicted_class, confidence


# # ==========================================================
# # TEST MODE
# # ==========================================================

# if __name__ == "__main__":

#     print("\nChoose Test Method")
#     print("1. Random dataset image")
#     print("2. Enter image path")

#     choice = input("Enter choice (1 or 2): ")

#     if choice == "1":

#         random_class = np.random.choice(class_labels)

#         class_folder = os.path.join(DATASET_PATH, random_class)

#         image_file = np.random.choice(os.listdir(class_folder))

#         test_image_path = os.path.join(class_folder, image_file)

#         print("\nSelected Image:", test_image_path)

#         predict_image(test_image_path)

#     elif choice == "2":

#         test_image_path = input("Enter ultrasound image path: ")

#         if os.path.exists(test_image_path):

#             predict_image(test_image_path)

#         else:

#             print("Image not found.")

#     else:

#         print("Invalid choice")












# # # ==========================================================
# # # THYROID IMAGE CLASSIFICATION (PROFESSIONAL OUTPUT)
# # # InceptionV3 Model - With Visualization
# # # ==========================================================

# # import os
# # import numpy as np
# # import tensorflow as tf
# # import matplotlib.pyplot as plt
# # from tensorflow.keras.models import load_model
# # from tensorflow.keras.preprocessing import image
# # from tensorflow.keras.applications.inception_v3 import preprocess_input

# # print("\n========== CLASSIFICATION MODULE ==========\n")

# # # ==========================================================
# # # PATH SETUP
# # # ==========================================================

# # BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# # PROJECT_ROOT = os.path.abspath(os.path.join(BASE_DIR, ".."))

# # MODEL_PATH = os.path.join(
# #     PROJECT_ROOT,
# #     "saved_models",
# #     "thyroid_inception_multiscale.h5"
# # )

# # DATASET_PATH = os.path.join(
# #     PROJECT_ROOT,
# #     "Thyroid Classification Dataset1",
# #     "Thyroid Classification Dataset1"
# # )

# # # ==========================================================
# # # LOAD MODEL
# # # ==========================================================

# # print("Loading model from:", MODEL_PATH)

# # model = load_model(MODEL_PATH)

# # print("Model Loaded Successfully")

# # # ==========================================================
# # # LOAD CLASS LABELS
# # # ==========================================================

# # class_labels = sorted([
# #     folder for folder in os.listdir(DATASET_PATH)
# #     if os.path.isdir(os.path.join(DATASET_PATH, folder))
# # ])

# # print("Detected Class Labels:", class_labels)

# # IMG_SIZE = 224

# # # ==========================================================
# # # THYROID STAGE DESCRIPTION
# # # ==========================================================

# # stage_description = {
# #     "normal thyroid": "Healthy thyroid gland. No abnormal nodules detected.",
# #     "benign": "Non-cancerous thyroid nodule detected. Usually slow growing.",
# #     "Malignant": "Cancerous thyroid nodule detected. Requires medical evaluation."
# # }

# # # ==========================================================
# # # IMAGE PREPROCESSING
# # # ==========================================================

# # def preprocess_image(img_path):

# #     img = image.load_img(img_path, target_size=(IMG_SIZE, IMG_SIZE))
# #     img_array = image.img_to_array(img)

# #     img_array = np.expand_dims(img_array, axis=0)
# #     img_array = preprocess_input(img_array)

# #     return img_array


# # # ==========================================================
# # # PROFESSIONAL VISUAL OUTPUT
# # # ==========================================================

# # def show_results(original_path, roi_image, predicted_class, confidence):

# #     original = image.load_img(original_path)

# #     description = stage_description.get(predicted_class, "Unknown stage")

# #     plt.figure(figsize=(10,6))

# #     # ORIGINAL IMAGE
# #     plt.subplot(1,2,1)
# #     plt.imshow(original)
# #     plt.title("Original Ultrasound Image")
# #     plt.axis("off")

# #     # ROI IMAGE
# #     plt.subplot(1,2,2)
# #     plt.imshow(roi_image.astype("uint8"))
# #     plt.title("Segmented Thyroid ROI")
# #     plt.axis("off")

# #     plt.suptitle(
# #         f"Prediction: {predicted_class} | Confidence: {round(confidence*100,2)}%",
# #         fontsize=14,
# #         fontweight="bold"
# #     )

# #     plt.figtext(
# #         0.5,
# #         0.01,
# #         f"Stage Information: {description}",
# #         wrap=True,
# #         horizontalalignment='center',
# #         fontsize=11
# #     )

# #     plt.tight_layout()

# #     plt.show()


# # # ==========================================================
# # # PREDICT FROM ROI (PIPELINE)
# # # ==========================================================

# # def predict_image(image_array, original_path=None):

# #     try:

# #         img_resized = tf.image.resize(image_array, (IMG_SIZE, IMG_SIZE))
# #         img_resized = np.expand_dims(img_resized, axis=0)

# #         img_resized = preprocess_input(img_resized)

# #         prediction = model.predict(img_resized)

# #         predicted_index = np.argmax(prediction)
# #         confidence = float(np.max(prediction))
# #         predicted_class = class_labels[predicted_index]

# #         print("\nPrediction:", predicted_class)
# #         print("Confidence:", round(confidence * 100, 2), "%")

# #         # Visualization
# #         if original_path is not None:
# #             show_results(original_path, image_array, predicted_class, confidence)

# #         return predicted_class, confidence

# #     except Exception as e:

# #         print("Classification Error:", e)
# #         return "Error", 0.0


# # # ==========================================================
# # # TEST MODE
# # # ==========================================================

# # if __name__ == "__main__":

# #     test_image_path = input("Enter image path: ")

# #     if os.path.exists(test_image_path):

# #         img_array = preprocess_image(test_image_path)

# #         prediction = model.predict(img_array)

# #         predicted_index = np.argmax(prediction)
# #         confidence = float(np.max(prediction))
# #         predicted_class = class_labels[predicted_index]

# #         print("\nPrediction:", predicted_class)
# #         print("Confidence:", round(confidence*100,2), "%")

# #     else:

# #         print("Image not found.")














# # # # ==========================================================
# # # # THYROID IMAGE CLASSIFICATION (PIPELINE READY)
# # # # InceptionV3 Model - Inference Only
# # # # ==========================================================

# # # import os
# # # import numpy as np
# # # import tensorflow as tf
# # # from tensorflow.keras.models import load_model
# # # from tensorflow.keras.preprocessing import image
# # # from tensorflow.keras.applications.inception_v3 import preprocess_input

# # # print("\n========== CLASSIFICATION MODULE ==========\n")

# # # # ==========================================================
# # # # SAFE PROJECT ROOT HANDLING
# # # # ==========================================================

# # # BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# # # PROJECT_ROOT = os.path.abspath(os.path.join(BASE_DIR, ".."))

# # # MODEL_PATH = os.path.join(
# # #     PROJECT_ROOT,
# # #     "saved_models",
# # #     "thyroid_inception_multiscale.h5"
# # # )

# # # print("Loading model from:", MODEL_PATH)

# # # # ==========================================================
# # # # LOAD MODEL
# # # # ==========================================================

# # # if not os.path.exists(MODEL_PATH):
# # #     raise FileNotFoundError(f"Model file not found at {MODEL_PATH}")

# # # model = load_model(MODEL_PATH)

# # # print("Model Loaded Successfully")

# # # # ==========================================================
# # # # LOAD CLASS LABELS
# # # # ==========================================================

# # # DATASET_PATH = os.path.join(
# # #     PROJECT_ROOT,
# # #     "Thyroid Classification Dataset1",
# # #     "Thyroid Classification Dataset1"
# # # )

# # # if not os.path.exists(DATASET_PATH):
# # #     raise FileNotFoundError(f"Dataset folder not found at {DATASET_PATH}")

# # # class_labels = sorted([
# # #     folder for folder in os.listdir(DATASET_PATH)
# # #     if os.path.isdir(os.path.join(DATASET_PATH, folder))
# # # ])

# # # print("Detected Class Labels:", class_labels)

# # # # ==========================================================
# # # # CONFIG
# # # # ==========================================================

# # # IMG_SIZE = 224

# # # # ==========================================================
# # # # IMAGE PATH PREPROCESSING
# # # # ==========================================================

# # # def preprocess_image(img_path):

# # #     img = image.load_img(img_path, target_size=(IMG_SIZE, IMG_SIZE))
# # #     img_array = image.img_to_array(img)

# # #     # Force writable array
# # #     img_array = np.array(img_array).copy()

# # #     img_array = np.expand_dims(img_array, axis=0)

# # #     img_array = preprocess_input(img_array)

# # #     return img_array

# # # # ==========================================================
# # # # PREDICT FROM IMAGE PATH
# # # # ==========================================================

# # # def run_classification(img_path):

# # #     try:

# # #         img_array = preprocess_image(img_path)

# # #         prediction = model.predict(img_array)

# # #         predicted_index = np.argmax(prediction)

# # #         confidence = float(np.max(prediction))

# # #         predicted_class = class_labels[predicted_index]

# # #         return predicted_class, confidence

# # #     except Exception as e:

# # #         print("Classification Error:", e)

# # #         return "Error", 0.0

# # # # ==========================================================
# # # # PIPELINE FUNCTION (NUMPY IMAGE INPUT)
# # # # ==========================================================

# # # def predict_image(image_array):

# # #     try:

# # #         if image_array is None:
# # #             raise ValueError("Invalid image input")

# # #         # Convert to writable numpy array
# # #         image_array = np.array(image_array).copy()

# # #         # Resize safely
# # #         img_resized = tf.image.resize(image_array, (IMG_SIZE, IMG_SIZE)).numpy().copy()

# # #         img_resized = np.expand_dims(img_resized, axis=0)

# # #         img_resized = preprocess_input(img_resized)

# # #         prediction = model.predict(img_resized)

# # #         predicted_index = np.argmax(prediction)

# # #         confidence = float(np.max(prediction))

# # #         predicted_class = class_labels[predicted_index]

# # #         print("\nPrediction:", predicted_class)
# # #         print("Confidence:", round(confidence * 100, 2), "%")

# # #         return predicted_class, confidence

# # #     except Exception as e:

# # #         print("Classification Error:", e)

# # #         return "Error", 0.0


# # # # ==========================================================
# # # # TEST BLOCK
# # # # ==========================================================

# # # if __name__ == "__main__":

# # #     test_image_path = input("Enter image path for testing: ")

# # #     if os.path.exists(test_image_path):

# # #         result, conf = run_classification(test_image_path)

# # #         print("\nPrediction:", result)

# # #         print("Confidence:", round(conf * 100, 2), "%")

# # #     else:

# # #         print("Image not found.")





















# # # # # # ==========================================================
# # # # # # THYROID IMAGE CLASSIFICATION (PIPELINE READY)
# # # # # # InceptionV3 Model - Inference Only
# # # # # # ==========================================================

# # # # # import os
# # # # # import numpy as np
# # # # # import tensorflow as tf
# # # # # from tensorflow.keras.models import load_model
# # # # # from tensorflow.keras.preprocessing import image

# # # # # print("\n========== CLASSIFICATION MODULE ==========\n")

# # # # # # ==========================================================
# # # # # # SAFE PROJECT ROOT HANDLING
# # # # # # ==========================================================

# # # # # BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# # # # # PROJECT_ROOT = os.path.abspath(os.path.join(BASE_DIR, ".."))

# # # # # MODEL_PATH = os.path.join(
# # # # #     PROJECT_ROOT,
# # # # #     "saved_models",
# # # # #     "thyroid_inception_multiscale.h5"
# # # # # )

# # # # # print("Loading model from:", MODEL_PATH)

# # # # # # ==========================================================
# # # # # # LOAD MODEL SAFELY
# # # # # # ==========================================================

# # # # # if not os.path.exists(MODEL_PATH):
# # # # #     raise FileNotFoundError(f"Model file not found at {MODEL_PATH}")

# # # # # model = load_model(MODEL_PATH)

# # # # # print("Model Loaded Successfully")

# # # # # # ==========================================================
# # # # # # AUTO LOAD CLASS LABELS FROM DATASET
# # # # # # ==========================================================

# # # # # DATASET_PATH = os.path.join(
# # # # #     PROJECT_ROOT,
# # # # #     "Thyroid Classification Dataset1",
# # # # #     "Thyroid Classification Dataset1"
# # # # # )

# # # # # if not os.path.exists(DATASET_PATH):
# # # # #     raise FileNotFoundError(f"Dataset folder not found at {DATASET_PATH}")

# # # # # class_labels = sorted([
# # # # #     folder for folder in os.listdir(DATASET_PATH)
# # # # #     if os.path.isdir(os.path.join(DATASET_PATH, folder))
# # # # # ])

# # # # # print("Detected Class Labels:", class_labels)

# # # # # # ==========================================================
# # # # # # CONFIG
# # # # # # ==========================================================

# # # # # IMG_SIZE = 224   # MUST match training size

# # # # # # ==========================================================
# # # # # # PIPELINE FUNCTION (Accepts NumPy Image)
# # # # # # ==========================================================

# # # # # def predict_image(image_array):
# # # # #     """
# # # # #     Input:
# # # # #         image_array → segmented numpy image (256x256x3)

# # # # #     Output:
# # # # #         predicted_class (str)
# # # # #         confidence (float)
# # # # #     """

# # # # #     try:
# # # # #         # Resize to model input size
# # # # #         img = tf.image.resize(image_array, (IMG_SIZE, IMG_SIZE))
# # # # #         img = img.numpy()

# # # # #         # Normalize
# # # # #         img = img / 255.0

# # # # #         # Add batch dimension
# # # # #         img = np.expand_dims(img, axis=0)

# # # # #         # Predict
# # # # #         prediction = model.predict(img)

# # # # #         predicted_index = np.argmax(prediction)
# # # # #         confidence = float(np.max(prediction))

# # # # #         predicted_class = class_labels[predicted_index]

# # # # #         print("\nPrediction:", predicted_class)
# # # # #         print("Confidence:", round(confidence * 100, 2), "%")

# # # # #         return predicted_class, confidence

# # # # #     except Exception as e:
# # # # #         print("Classification Error:", e)
# # # # #         return "Error", 0.0


# # # # # # ==========================================================
# # # # # # MANUAL IMAGE PATH TESTING FUNCTION
# # # # # # ==========================================================

# # # # # def run_classification(img_path):
# # # # #     """
# # # # #     Input:
# # # # #         img_path → path to image file

# # # # #     Output:
# # # # #         predicted_class (str)
# # # # #         confidence (float)
# # # # #     """

# # # # #     try:
# # # # #         img = image.load_img(img_path, target_size=(IMG_SIZE, IMG_SIZE))
# # # # #         img_array = image.img_to_array(img)

# # # # #         img_array = img_array / 255.0
# # # # #         img_array = np.expand_dims(img_array, axis=0)

# # # # #         prediction = model.predict(img_array)

# # # # #         predicted_index = np.argmax(prediction)
# # # # #         confidence = float(np.max(prediction))

# # # # #         predicted_class = class_labels[predicted_index]

# # # # #         return predicted_class, confidence

# # # # #     except Exception as e:
# # # # #         print("Classification Error:", e)
# # # # #         return "Error", 0.0


# # # # # # ==========================================================
# # # # # # OPTIONAL TEST BLOCK
# # # # # # ==========================================================

# # # # # if __name__ == "__main__":

# # # # #     test_image_path = input("Enter image path for testing: ")

# # # # #     if os.path.exists(test_image_path):
# # # # #         result, conf = run_classification(test_image_path)
# # # # #         print("\nPrediction:", result)
# # # # #         print("Confidence:", round(conf * 100, 2), "%")
# # # # #     else:
# # # # #         print("Image not found.")
# # # # # ==========================================================
# # # # # THYROID IMAGE CLASSIFICATION (PIPELINE READY)
# # # # # InceptionV3 Model - Inference Only
# # # # # ==========================================================

# # # # import os
# # # # import numpy as np
# # # # import tensorflow as tf
# # # # from tensorflow.keras.models import load_model
# # # # from tensorflow.keras.preprocessing import image
# # # # from tensorflow.keras.applications.inception_v3 import preprocess_input

# # # # print("\n========== CLASSIFICATION MODULE ==========\n")

# # # # # ==========================================================
# # # # # SAFE PROJECT ROOT HANDLING
# # # # # ==========================================================

# # # # BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# # # # PROJECT_ROOT = os.path.abspath(os.path.join(BASE_DIR, ".."))

# # # # MODEL_PATH = os.path.join(
# # # #     PROJECT_ROOT,
# # # #     "saved_models",
# # # #     "thyroid_inception_multiscale.h5"
# # # # )

# # # # print("Loading model from:", MODEL_PATH)

# # # # # ==========================================================
# # # # # LOAD MODEL SAFELY
# # # # # ==========================================================

# # # # if not os.path.exists(MODEL_PATH):
# # # #     raise FileNotFoundError(f"Model file not found at {MODEL_PATH}")

# # # # model = load_model(MODEL_PATH)
# # # # print("Model Loaded Successfully")

# # # # # ==========================================================
# # # # # AUTO LOAD CLASS LABELS FROM DATASET
# # # # # ==========================================================

# # # # DATASET_PATH = os.path.join(
# # # #     PROJECT_ROOT,
# # # #     "Thyroid Classification Dataset1",
# # # #     "Thyroid Classification Dataset1"
# # # # )

# # # # if not os.path.exists(DATASET_PATH):
# # # #     raise FileNotFoundError(f"Dataset folder not found at {DATASET_PATH}")

# # # # class_labels = sorted([
# # # #     folder for folder in os.listdir(DATASET_PATH)
# # # #     if os.path.isdir(os.path.join(DATASET_PATH, folder))
# # # # ])

# # # # print("Detected Class Labels:", class_labels)

# # # # # ==========================================================
# # # # # CONFIG
# # # # # ==========================================================

# # # # IMG_SIZE = 224   # Must match training size

# # # # # ==========================================================
# # # # # IMAGE PATH → NUMPY ARRAY PREPROCESSING FOR InceptionV3
# # # # # ==========================================================

# # # # def preprocess_image(img_path):
# # # #     """
# # # #     Loads image from path and preprocesses it for InceptionV3.
# # # #     """
# # # #     img = image.load_img(img_path, target_size=(IMG_SIZE, IMG_SIZE))
# # # #     img_array = image.img_to_array(img)
# # # #     img_array = np.expand_dims(img_array, axis=0)

# # # #     # Apply InceptionV3-specific preprocessing
# # # #     img_array = preprocess_input(img_array)

# # # #     return img_array

# # # # # ==========================================================
# # # # # PREDICTION FUNCTION FOR IMAGE PATH
# # # # # ==========================================================

# # # # def run_classification(img_path):
# # # #     """
# # # #     Input:
# # # #         img_path → path to image file
# # # #     Output:
# # # #         predicted_class (str)
# # # #         confidence (float)
# # # #     """
# # # #     try:
# # # #         img_array = preprocess_image(img_path)

# # # #         prediction = model.predict(img_array)
# # # #         predicted_index = np.argmax(prediction)
# # # #         confidence = float(np.max(prediction))
# # # #         predicted_class = class_labels[predicted_index]

# # # #         return predicted_class, confidence

# # # #     except Exception as e:
# # # #         print("Classification Error:", e)
# # # #         return "Error", 0.0

# # # # # ==========================================================
# # # # # PREDICTION FUNCTION FOR NUMPY IMAGE (PIPELINE USE)
# # # # # ==========================================================

# # # # def predict_image(image_array):
# # # #     """
# # # #     Input:
# # # #         image_array → NumPy image (HxWx3)
# # # #     Output:
# # # #         predicted_class (str)
# # # #         confidence (float)
# # # #     """
# # # #     try:
# # # #         # Resize to model input
# # # #         img_resized = tf.image.resize(image_array, (IMG_SIZE, IMG_SIZE))
# # # #         img_resized = np.expand_dims(img_resized, axis=0)

# # # #         # Preprocess for InceptionV3
# # # #         img_resized = preprocess_input(img_resized)

# # # #         prediction = model.predict(img_resized)
# # # #         predicted_index = np.argmax(prediction)
# # # #         confidence = float(np.max(prediction))
# # # #         predicted_class = class_labels[predicted_index]

# # # #         print("\nPrediction:", predicted_class)
# # # #         print("Confidence:", round(confidence * 100, 2), "%")

# # # #         return predicted_class, confidence

# # # #     except Exception as e:
# # # #         print("Classification Error:", e)
# # # #         return "Error", 0.0

# # # # # ==========================================================
# # # # # OPTIONAL TEST BLOCK
# # # # # ==========================================================

# # # # if __name__ == "__main__":

# # # #     test_image_path = input("Enter image path for testing: ")

# # # #     if os.path.exists(test_image_path):
# # # #         result, conf = run_classification(test_image_path)
# # # #         print("\nPrediction:", result)
# # # #         print("Confidence:", round(conf * 100, 2), "%")
# # # #     else:
# # # #         print("Image not found.")