# ==========================================================
# THYROID CLASSIFICATION BACKEND + DATABASE SAVE + LOGGING
# ==========================================================

import os
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.image import load_img, img_to_array, ImageDataGenerator
from tensorflow.keras.applications import InceptionV3
from tensorflow.keras.layers import *
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping
from sklearn.model_selection import train_test_split
import pymysql
from datetime import datetime
import logging

print("\n========== THYROID CLASSIFICATION BACKEND ==========\n")

# ---------------- SETUP LOGGING ----------------
LOG_FILE = r"C:\Users\ELCOT\Desktop\project\thyroid_backend.log"
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    filemode="a"
)
logging.info("----- Starting Thyroid Classification Backend -----")

# ---------------- PATH CONFIGURATION ----------------
BASE_PATH = r"C:\Users\ELCOT\Desktop\project"
DATASET_PATH = os.path.join(BASE_PATH, "Thyroid Classification Dataset1")
IMG_SIZE = 256
BATCH_SIZE = 8
EPOCHS = 15
MODEL_VERSION = "InceptionV3_v1"

# ---------------- LOAD DATASET ----------------
X, Y, image_paths, class_labels = [], [], [], []

try:
    for root, dirs, files in os.walk(DATASET_PATH):
        for folder in dirs:
            class_labels.append(folder)
    class_labels = sorted(list(set(class_labels)))
    class_mapping = {label: idx for idx, label in enumerate(class_labels)}
    logging.info(f"Detected Classes: {class_mapping}")
except Exception as e:
    logging.error(f"Error detecting classes: {e}")
    raise

# Recursive loader
for class_label in class_labels:
    class_path = os.path.join(DATASET_PATH, class_label)
    for root, dirs, files in os.walk(class_path):
        for file in files:
            if file.lower().endswith(("jpg", "jpeg", "png")):
                img_path = os.path.join(root, file)
                img = load_img(img_path, target_size=(IMG_SIZE, IMG_SIZE))
                img = img_to_array(img) / 255.0
                X.append(img)
                Y.append(class_mapping[class_label])
                image_paths.append(img_path)

X = np.array(X)
Y = np.array(Y)

if len(X) < 2:
    logging.error("Not enough images to train. Need at least 2 images.")
    raise ValueError("Not enough images to train. Need at least 2 images.")

logging.info(f"Total Images Loaded: {len(X)}")

# ---------------- TRAIN/VALIDATION SPLIT ----------------
X_train, X_val, Y_train, Y_val, paths_train, paths_val = train_test_split(
    X, Y, image_paths, test_size=0.2, random_state=42
)

# ---------------- DATA AUGMENTATION ----------------
datagen = ImageDataGenerator(rotation_range=15, zoom_range=0.1, horizontal_flip=True)
datagen.fit(X_train)

# ---------------- MODEL BUILDING ----------------
base_model = InceptionV3(weights='imagenet', include_top=False, input_shape=(IMG_SIZE, IMG_SIZE, 3))
base_model.trainable = False

x1 = GlobalAveragePooling2D()(base_model.output)

# Multi-scale CNN branch
input_layer = base_model.input
m1 = Conv2D(32, 3, activation='relu', padding='same')(input_layer)
m2 = Conv2D(32, 5, activation='relu', padding='same')(input_layer)
m3 = Conv2D(32, 7, activation='relu', padding='same')(input_layer)
multi_scale = Concatenate()([m1, m2, m3])
multi_scale = MaxPooling2D()(multi_scale)
multi_scale = GlobalAveragePooling2D()(multi_scale)

# Feature fusion
merged = Concatenate()([x1, multi_scale])
merged = Dense(256, activation='relu')(merged)
merged = Dropout(0.5)(merged)
output = Dense(len(class_labels), activation='softmax')(merged)

model = Model(inputs=input_layer, outputs=output)
model.compile(optimizer=Adam(1e-4), loss='sparse_categorical_crossentropy', metrics=['accuracy'])

# ---------------- TRAINING ----------------
early_stop = EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)

logging.info("Starting model training...")
model.fit(
    datagen.flow(X_train, Y_train, batch_size=BATCH_SIZE),
    validation_data=(X_val, Y_val),
    epochs=EPOCHS,
    callbacks=[early_stop]
)
logging.info("Initial training completed.")

# Fine-tune last 30 layers
for layer in base_model.layers[-30:]:
    layer.trainable = True

model.compile(optimizer=Adam(1e-5), loss='sparse_categorical_crossentropy', metrics=['accuracy'])
logging.info("Starting fine-tuning last 30 layers...")
model.fit(datagen.flow(X_train, Y_train, batch_size=BATCH_SIZE), validation_data=(X_val, Y_val), epochs=5)
logging.info("Fine-tuning completed.")

# ---------------- DATABASE CONNECTION ----------------
try:
    conn = pymysql.connect(
        host="localhost",
        user="root",
        password="root",
        database="thyroid_ai"
    )
    cursor = conn.cursor()
    logging.info("Database connection established.")
except Exception as e:
    logging.error(f"Database connection failed: {e}")
    raise

# Ensure table exists with image_name column
cursor.execute("""
CREATE TABLE IF NOT EXISTS prediction_results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    image_name VARCHAR(255),
    image_path VARCHAR(255),
    patient_id VARCHAR(50),
    scan_date DATETIME,
    predicted_class VARCHAR(50),
    confidence FLOAT,
    model_name VARCHAR(50),
    model_version VARCHAR(20),
    segmentation_used BOOLEAN,
    processed_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""")
conn.commit()
logging.info("Database table ensured.")

# ---------------- PREDICTION & SAVE ----------------
insert_data = []
logging.info("Starting prediction and database insert...")

# Counter for auto patient IDs
auto_patient_counter = 1

for i, sample in enumerate(X_val):
    prediction = model.predict(np.expand_dims(sample, axis=0))
    confidence = float(np.max(prediction))
    predicted_class = class_labels[np.argmax(prediction)]
    image_path = paths_val[i]
    
    # Always fill image_name
    image_name = os.path.basename(image_path) or f"image_{i}.jpg"
    
    # Extract patient_id or auto-generate
    if "_" in image_name:
        patient_id = image_name.split("_")[0]
        if not patient_id.strip():
            patient_id = f"patient_{auto_patient_counter:03d}"
            auto_patient_counter += 1
    else:
        patient_id = os.path.splitext(image_name)[0]
        if not patient_id.strip():
            patient_id = f"patient_{auto_patient_counter:03d}"
            auto_patient_counter += 1

    scan_date = datetime.now()
    segmentation_used = True

    insert_data.append((
        image_name,
        image_path,
        patient_id,
        scan_date,
        predicted_class,
        confidence,
        "InceptionV3",
        MODEL_VERSION,
        segmentation_used
    ))
    
    logging.info(f"Prediction: {predicted_class} | Confidence: {confidence:.4f} | "
                 f"Patient: {patient_id} | Image: {image_name}")

# Insert all at once
try:
    query = """
    INSERT INTO prediction_results
    (image_name, image_path, patient_id, scan_date, predicted_class, confidence, model_name, model_version, segmentation_used)
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
    """
    cursor.executemany(query, insert_data)
    conn.commit()
    logging.info(f"Inserted {len(insert_data)} predictions into database.")
except Exception as e:
    logging.error(f"Database insertion error: {e}")

# ---------------- CLOSE CONNECTION ----------------
cursor.close()
conn.close()
logging.info("Database connection closed.")
logging.info("Backend classification and database save completed successfully.")