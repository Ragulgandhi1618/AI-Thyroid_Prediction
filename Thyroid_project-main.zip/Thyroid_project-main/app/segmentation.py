# ==========================================================
# THYROID ULTRASOUND SEGMENTATION + CLASSIFICATION PIPELINE
# ==========================================================

import os
import random
import numpy as np
import cv2
import matplotlib.pyplot as plt
import seaborn as sns

from tensorflow.keras.preprocessing.image import load_img, img_to_array
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import ImageDataGenerator

from sklearn.metrics import classification_report, confusion_matrix

# ==========================================================
# CONFIGURATION
# ==========================================================

IMG_HEIGHT = 224
IMG_WIDTH = 224

DATASET_PATH = r"C:\Users\ELCOT\Desktop\project\Thyroid Classification Dataset1\dataset"

MODEL_PATH = r"C:\Users\ELCOT\Desktop\project\saved_models\thyroid_inceptionv3_model.h5"

CLASS_NAMES = ["benign", "malignant", "normal"]

# ==========================================================
# GET RANDOM IMAGE
# ==========================================================

def get_random_image(dataset_path):

    image_list = []

    for root, dirs, files in os.walk(dataset_path):

        for file in files:

            if file.lower().endswith((".png", ".jpg", ".jpeg")):

                image_list.append(os.path.join(root, file))

    if len(image_list) == 0:
        raise Exception("No images found")

    print("Total images found:", len(image_list))

    return random.choice(image_list)


# ==========================================================
# IMAGE RESIZE
# ==========================================================

def resize_image(img):

    return cv2.resize(img, (IMG_WIDTH, IMG_HEIGHT))


# ==========================================================
# DENOISING
# ==========================================================

def denoise_image(img):

    return cv2.bilateralFilter(img, 9, 75, 75)


# ==========================================================
# CLAHE CONTRAST ENHANCEMENT
# ==========================================================

def enhance_image(img):

    lab = cv2.cvtColor(img, cv2.COLOR_RGB2LAB)

    l, a, b = cv2.split(lab)

    clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8,8))

    l_clahe = clahe.apply(l)

    merged = cv2.merge((l_clahe, a, b))

    enhanced = cv2.cvtColor(merged, cv2.COLOR_LAB2RGB)

    return enhanced


# ==========================================================
# IMAGE SHARPENING
# ==========================================================

def sharpen_image(img):

    kernel = np.array([
        [0,-1,0],
        [-1,5,-1],
        [0,-1,0]
    ])

    sharp = cv2.filter2D(img, -1, kernel)

    return sharp


# ==========================================================
# SEGMENT THYROID REGION
# ==========================================================

def segment_thyroid(img):

    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)

    blur = cv2.GaussianBlur(gray, (5,5), 0)

    _, mask = cv2.threshold(
        blur,
        0,
        255,
        cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )

    kernel = np.ones((5,5), np.uint8)

    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)

    contours, _ = cv2.findContours(
        mask,
        cv2.RETR_EXTERNAL,
        cv2.CHAIN_APPROX_SIMPLE
    )

    clean_mask = np.zeros_like(mask)

    if contours:

        largest = max(contours, key=cv2.contourArea)

        cv2.drawContours(clean_mask, [largest], -1, 255, -1)

    mask_rgb = cv2.cvtColor(clean_mask, cv2.COLOR_GRAY2RGB)

    segmented = cv2.bitwise_and(img, mask_rgb)

    return clean_mask, segmented


# ==========================================================
# SEGMENTATION PIPELINE
# ==========================================================

def segment_image(image_path, visualize=True):

    print("\nRunning Segmentation Pipeline")
    print("Selected Image:", image_path)

    img = load_img(image_path)
    img = img_to_array(img).astype(np.uint8)

    resized = resize_image(img)

    denoised = denoise_image(resized)

    enhanced = enhance_image(denoised)

    sharpened = sharpen_image(enhanced)

    mask, segmented = segment_thyroid(sharpened)

    segmented = segmented.astype("float32")
    segmented = segmented / 255.0
    segmented = (segmented - 0.5) * 2

    if visualize:

        fig, ax = plt.subplots(1,6, figsize=(24,5))

        ax[0].imshow(resized)
        ax[0].set_title("Resized")

        ax[1].imshow(denoised)
        ax[1].set_title("Denoised")

        ax[2].imshow(enhanced)
        ax[2].set_title("Enhanced")

        ax[3].imshow(sharpened)
        ax[3].set_title("Sharpened")

        ax[4].imshow(mask, cmap="gray")
        ax[4].set_title("Mask")

        display_img = (segmented + 1) / 2

        ax[5].imshow(display_img)
        ax[5].set_title("Segmented ROI")

        for a in ax:
            a.axis("off")

        plt.tight_layout()
        plt.show(block=False)
        plt.pause(3)
        plt.close()

    print("Segmentation Completed")

    return segmented


# ==========================================================
# CLASSIFICATION WITH TEST TIME AUGMENTATION
# ==========================================================

def classify_image(model, image):

    images = [
        image,
        np.fliplr(image),
        np.flipud(image)
    ]

    preds = []

    for img in images:

        img = np.expand_dims(img, axis=0)

        pred = model.predict(img)

        preds.append(pred)

    preds = np.mean(preds, axis=0)

    pred_class = np.argmax(preds)

    confidence = np.max(preds)

    print("\nPrediction Results")
    print("----------------------")

    print("Predicted Class :", CLASS_NAMES[pred_class])

    print("Confidence Score:", round(confidence*100,2), "%")

    print("\nClass Probabilities:")

    for i in range(len(CLASS_NAMES)):

        print(CLASS_NAMES[i], ":", round(preds[0][i]*100,2), "%")


# ==========================================================
# MODEL PERFORMANCE
# ==========================================================

def evaluate_model(model):

    print("\nEvaluating Model Performance...\n")

    datagen = ImageDataGenerator(rescale=1./255)

    generator = datagen.flow_from_directory(
        DATASET_PATH,
        target_size=(IMG_HEIGHT, IMG_WIDTH),
        batch_size=32,
        class_mode="categorical",
        shuffle=False
    )

    results = model.evaluate(generator)

    loss = results[0]
    accuracy = results[1]
    auc = results[2]
    precision = results[3]
    recall = results[4]

    f1 = 2*(precision*recall)/(precision+recall)

    print("\nModel Performance Metrics")
    print("---------------------------")

    print("Loss      :", loss)
    print("Accuracy  :", accuracy)
    print("AUC       :", auc)
    print("Precision :", precision)
    print("Recall    :", recall)
    print("F1 Score  :", f1)

    preds = model.predict(generator)

    y_pred = np.argmax(preds, axis=1)

    cm = confusion_matrix(generator.classes, y_pred)

    plt.figure(figsize=(6,6))

    sns.heatmap(
        cm,
        annot=True,
        cmap="Blues",
        xticklabels=CLASS_NAMES,
        yticklabels=CLASS_NAMES
    )

    plt.title("Confusion Matrix")
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.show()

    print("\nClassification Report\n")

    print(classification_report(
        generator.classes,
        y_pred,
        target_names=CLASS_NAMES
    ))


# ==========================================================
# MAIN
# ==========================================================

if __name__ == "__main__":

    print("\nRunning segmentation module independently\n")

    try:

        random_image = get_random_image(DATASET_PATH)

        segmented = segment_image(random_image)

        print("Segmented Output Shape:", segmented.shape)

    except Exception as e:

        print("Segmentation Error:", e)

    try:

        model = load_model(MODEL_PATH)

        print("\nModel Summary\n")

        model.summary()

        classify_image(model, segmented)

        evaluate_model(model)

    except Exception as e:

        print("\nModel Error:", e)

# # ============================================
# # THYROID ULTRASOUND SEGMENTATION MODULE
# # ============================================

# import os
# import random
# import numpy as np
# import cv2
# import matplotlib.pyplot as plt

# from tensorflow.keras.preprocessing.image import load_img, img_to_array
# from tensorflow.keras.models import load_model

# # ============================================
# # CONFIGURATION
# # ============================================

# IMG_HEIGHT = 256
# IMG_WIDTH = 256

# DATASET_PATH = r"C:\Users\ELCOT\Desktop\project\Thyroid Classification Dataset1"

# MODEL_PATH = r"C:\Users\ELCOT\Desktop\project\saved_models\classification_model.h5"


# # ============================================
# # GET RANDOM IMAGE FROM DATASET
# # ============================================

# def get_random_image(dataset_path):

#     image_list = []

#     for root, dirs, files in os.walk(dataset_path):

#         for file in files:

#             if file.lower().endswith((".png", ".jpg", ".jpeg")):

#                 image_list.append(os.path.join(root, file))

#     if len(image_list) == 0:
#         raise Exception("No images found in dataset folder.")

#     print("Total images found:", len(image_list))

#     return random.choice(image_list)


# # ============================================
# # IMAGE RESIZE
# # ============================================

# def resize_image(img):

#     resized = cv2.resize(img, (IMG_WIDTH, IMG_HEIGHT))

#     return resized


# # ============================================
# # DENOISING (BILATERAL FILTER)
# # ============================================

# def denoise_image(img):

#     denoised = cv2.bilateralFilter(img, 9, 75, 75)

#     return denoised


# # ============================================
# # BACKGROUND ENHANCEMENT (CLAHE)
# # ============================================

# def enhance_background(img):

#     lab = cv2.cvtColor(img, cv2.COLOR_RGB2LAB)

#     l, a, b = cv2.split(lab)

#     clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))

#     l_clahe = clahe.apply(l)

#     merged = cv2.merge((l_clahe, a, b))

#     enhanced = cv2.cvtColor(merged, cv2.COLOR_LAB2RGB)

#     return enhanced


# # ============================================
# # SEGMENT THYROID REGION
# # ============================================

# def segment_thyroid(img):

#     gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)

#     _, mask = cv2.threshold(
#         gray,
#         0,
#         255,
#         cv2.THRESH_BINARY + cv2.THRESH_OTSU
#     )

#     kernel = np.ones((5,5), np.uint8)

#     mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

#     mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)

#     contours, _ = cv2.findContours(
#         mask,
#         cv2.RETR_EXTERNAL,
#         cv2.CHAIN_APPROX_SIMPLE
#     )

#     clean_mask = np.zeros_like(mask)

#     if contours:

#         largest = max(contours, key=cv2.contourArea)

#         cv2.drawContours(clean_mask, [largest], -1, 255, -1)

#     mask_rgb = cv2.cvtColor(clean_mask, cv2.COLOR_GRAY2RGB)

#     segmented = cv2.bitwise_and(img, mask_rgb)

#     return clean_mask, segmented


# # ============================================
# # SEGMENTATION PIPELINE
# # ============================================

# def segment_image(image_path, visualize=True):

#     print("\nRunning Segmentation Pipeline")
#     print("Selected Image:", image_path)

#     img = load_img(image_path)
#     img = img_to_array(img).astype(np.uint8)

#     resized = resize_image(img)

#     denoised = denoise_image(resized)

#     enhanced = enhance_background(denoised)

#     mask, segmented = segment_thyroid(enhanced)

#     segmented = segmented.astype(np.float32) / 255.0

#     if visualize:

#         fig, ax = plt.subplots(1,5, figsize=(20,5))

#         ax[0].imshow(resized)
#         ax[0].set_title("Resized")

#         ax[1].imshow(denoised)
#         ax[1].set_title("Denoised")

#         ax[2].imshow(enhanced)
#         ax[2].set_title("Enhanced")

#         ax[3].imshow(mask, cmap="gray")
#         ax[3].set_title("Mask")

#         ax[4].imshow(segmented)
#         ax[4].set_title("Segmented ROI")

#         for a in ax:
#             a.axis("off")

#         plt.tight_layout()
#         plt.show()

#     print("Segmentation Completed")

#     return segmented


# # ============================================
# # FUNCTION USED BY CLASSIFICATION
# # ============================================

# def segment_and_extract_roi(image_np):

#     resized = resize_image(image_np)

#     denoised = denoise_image(resized)

#     enhanced = enhance_background(denoised)

#     _, segmented = segment_thyroid(enhanced)

#     segmented = segmented.astype(np.float32) / 255.0

#     return segmented


# # ============================================
# # RUN MODULE INDEPENDENTLY
# # ============================================

# if __name__ == "__main__":

#     print("\nRunning segmentation module independently")

#     try:

#         random_image = get_random_image(DATASET_PATH)

#         segmented = segment_image(random_image, visualize=True)

#         print("Segmented Output Shape:", segmented.shape)

#     except Exception as e:

#         print("Dataset Error:", e)

#     try:

#         model = load_model(MODEL_PATH)

#         print("\nClassification Model Summary\n")

#         model.summary()

#     except:

#         print("\nclassification_model.h5 not found in saved_models folder")

