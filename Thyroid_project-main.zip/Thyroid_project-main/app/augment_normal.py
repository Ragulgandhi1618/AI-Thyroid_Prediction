import os
import cv2
import numpy as np
import random

# ================= PATHS =================
NORMAL_PATH = r"C:\Users\ELCOT\Desktop\project\Thyroid Classification Dataset1\Thyroid Classification Dataset1\normal"
AUG_PATH = os.path.join(NORMAL_PATH, "augmented")

os.makedirs(AUG_PATH, exist_ok=True)

# ================= AUGMENTATION FUNCTIONS =================
def augment_image(img):
    aug_images = []

    # Original
    aug_images.append(img)

    # Flip horizontally
    aug_images.append(cv2.flip(img, 1))

    # Rotate ±15 degrees
    h, w = img.shape[:2]
    for angle in [-15, 15]:
        M = cv2.getRotationMatrix2D((w/2, h/2), angle, 1)
        rotated = cv2.warpAffine(img, M, (w,h))
        aug_images.append(rotated)

    # Brightness adjustment
    for factor in [0.7, 1.3]:
        bright = cv2.convertScaleAbs(img, alpha=factor, beta=0)
        aug_images.append(bright)

    # Gaussian Blur
    blur = cv2.GaussianBlur(img, (5,5), 0)
    aug_images.append(blur)

    return aug_images

# ================= PROCESSING =================
images = os.listdir(NORMAL_PATH)
images = [i for i in images if i.lower().endswith(('.jpg','.jpeg','.png'))]

count = 0
for img_name in images:
    img_path = os.path.join(NORMAL_PATH, img_name)
    img = cv2.imread(img_path)
    if img is None:
        continue
    
    aug_imgs = augment_image(img)
    for i, aug in enumerate(aug_imgs):
        save_name = f"{os.path.splitext(img_name)[0]}_aug{i+1}.jpg"
        save_path = os.path.join(AUG_PATH, save_name)
        cv2.imwrite(save_path, aug)
        count += 1

print(f"Augmentation complete! {count} images saved in {AUG_PATH}")