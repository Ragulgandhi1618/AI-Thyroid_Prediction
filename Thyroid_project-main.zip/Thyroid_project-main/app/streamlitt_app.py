# ==========================================================
# AI THYROID DIAGNOSIS SYSTEM – PROFESSIONAL WEB APPLICATION
# ==========================================================
import streamlit as st
import pymysql
import pandas as pd
import numpy as np
import cv2
import tensorflow as tf
import matplotlib.pyplot as plt
from datetime import datetime
import os
from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.pagesizes import A4
import qrcode
import time
import random
import matplotlib.animation as animation


def generate_patient_id():
    return f"PAT-{datetime.now().strftime('%Y%m%d')}-{random.randint(1000,9999)}"

# ================= PATIENT ID GENERATOR =================
# def generate_patient_id():
#     return f"PAT-{datetime.now().strftime('%Y%m%d%H%M%S')}"

# ================= PAGE CONFIG =================

st.set_page_config(
    page_title="AI Thyroid Diagnosis System",
    layout="wide"
)


# ================= SESSION STATE =================
if "registered" not in st.session_state:
    st.session_state.registered = False

if "patient_id" not in st.session_state:
    st.session_state.patient_id = ""


# ================= UI STYLE =================

st.markdown("""
<style>

/* ===== LAYOUT ===== */
.block-container{
    max-width:1200px;
    padding-top:2rem;
}

/* ===== BACKGROUND ===== */
.stApp{
    background:
    linear-gradient(rgba(8,20,40,0.92),rgba(8,20,40,0.92)),
    url("https://images.unsplash.com/photo-1581093458791-9d09e4b0a5e4");
    background-size:cover;
    background-attachment:fixed;
}

/* ===== TITLES ===== */
h1{
    color:#ffffff !important;
    font-size:42px !important;
    font-weight:800;
}

h2{
    color:#ffffff !important;
    font-size:30px !important;
}

h3{
    color:#ffffff !important;
    font-size:24px !important;
}
/* ===== SECTION TITLES BOLD WHITE ===== */
.section-title {
    font-size: 22px;
    font-weight: 900;
    color: white !important;
    margin-top: 25px;
    margin-bottom: 10px;
}
            
/* ===== GENDER TEXT WHITE ===== */
div[role="radiogroup"] label {
    color: white !important;
    font-weight: 600 !important;
    input[type="radio"]:checked + div {
    background: #2563eb !important;
    color: white !important;
}        
}

/* Dark background to match UI */
div[role="radiogroup"] {
    background: #1e293b !important;
    border: 1px solid #334155 !important;
    border-radius: 8px;
    padding: 8px;
}

/* ===== LABELS ===== */
label, .stTextInput label, .stNumberInput label, .stSelectbox label{
    color:white !important;
    font-weight:600;
}

/* ===== CARD ===== */
# .card{
#     background:rgba(255,255,255,0.95);
#     padding:25px;
#     border-radius:18px;
#     box-shadow:0px 8px 25px rgba(0,0,0,0.35);
#     margin-bottom:25px;
#     color:#1e293b;
# }
.form-card{
    background: rgba(255,255,255,0.08);
    backdrop-filter: blur(12px);
    border-radius: 20px;
    padding: 30px;
    border: 1px solid rgba(255,255,255,0.15);
    box-shadow: 0 10px 35px rgba(0,0,0,0.5);
    margin-top: 20px;
}            

/* ✅ FIX: MAKE CARD TEXT BLACK */
# .card h1{
#     color:black !important;
# }

# .card p{
#     color:black !important;
# }
.card h1{
    color:white !important;
    font-weight:900;
}

.card p{
    color:white !important;
}            

/* ===== FEATURE BOX ===== */
.feature{
    background:linear-gradient(135deg,#2563eb,#06b6d4);
    color:white;
    padding:30px;
    border-radius:18px;
    text-align:center;
    box-shadow:0px 10px 25px rgba(0,0,0,0.35);
    transition:0.3s;
    height:210px;
}

.feature:hover{
    transform:translateY(-6px);
}

/* ===== RESULT BOX ===== */
.resultbox{
    background:linear-gradient(135deg,#2563eb,#06b6d4);
    color:white;
    padding:25px;
    border-radius:18px;
    box-shadow:0px 10px 25px rgba(0,0,0,0.35);
    font-size:18px;
}

/* ===== RECOMMENDATION BOX ===== */
.recbox{
    background:linear-gradient(135deg,#22c55e,#16a34a);
    color:white;
    padding:20px;
    border-radius:15px;
    margin-bottom:10px;
}

/* ===== BUTTON ===== */
.stButton>button{
    background:linear-gradient(90deg,#2563eb,#06b6d4);
    color:white;
    border-radius:10px;
    height:45px;
    width:220px;
    font-weight:bold;
}

/* ===== SIDEBAR ===== */
section[data-testid="stSidebar"]{
    background:#0f172a;
}

section[data-testid="stSidebar"] *{
    color:white;
}
            

</style>
""", unsafe_allow_html=True)

# ================= CONFIG =================

MODEL_PATH=r"C:\\Users\\ELCOT\\Desktop\\project\\saved_models\\thyroid_inceptionv3_model.h5"

REPORT_FOLDER="reports"
os.makedirs(REPORT_FOLDER,exist_ok=True)

class_labels=['malignant','benign','normal']

DB_CONFIG={
    "host":"localhost",
    "user":"root",
    "password":"root",
    "database":"thyroid_ai"
}

# ================= LOAD MODEL =================

@st.cache_resource
def load_model():
    try:
        model=tf.keras.models.load_model(MODEL_PATH)
        return model
    except:
        st.error("Model file not found. Ensure the path is correct.")
        return None

model=load_model()

# ================= DATABASE =================

def get_connection():
    return pymysql.connect(**DB_CONFIG)

def load_data():
    try:
        conn=get_connection()
        df=pd.read_sql("SELECT * FROM prediction_results",conn)
        conn.close()
        return df
    except:
        return pd.DataFrame()
    

# ================= SAVE PREDICTION =================
def save_prediction(patient_id, image_name, predicted_class, confidence):
    try:
        conn = get_connection()
        cursor = conn.cursor()

        query = """
        INSERT INTO prediction_results 
        (patient_id, image_name, predicted_class, confidence, scan_date)
        VALUES (%s, %s, %s, %s, CURDATE())
        """

        cursor.execute(query, (
            patient_id, image_name, predicted_class, confidence
        ))

        conn.commit()
        conn.close()

    except Exception as e:
        st.error(f"Database Error: {e}")    

# ================= LOAD PATIENT HISTORY =================
def load_patient_history(patient_id):
    try:
        conn = get_connection()

        query = """
        SELECT predicted_class, confidence, processed_at
        FROM prediction_results
        WHERE patient_id = %s
        ORDER BY processed_at DESC
        """

        df = pd.read_sql(query, conn, params=[patient_id])
        conn.close()

        return df

    except:
        return pd.DataFrame()        
    

# ================= PROFILE DATABASE =================

def save_profile(patient_id, name, age, gender, theme, notifications):
    try:
        conn = get_connection()
        cursor = conn.cursor()

        query = """
        INSERT INTO patient_profiles 
        (patient_id, name, age, gender, theme, notifications)
        VALUES (%s, %s, %s, %s, %s, %s)
        ON DUPLICATE KEY UPDATE
            name=%s,
            age=%s,
            gender=%s,
            theme=%s,
            notifications=%s
        """

        cursor.execute(query, (
            patient_id, name, age, gender, theme, notifications,
            name, age, gender, theme, notifications
        ))

        conn.commit()
        conn.close()

    except Exception as e:
        st.error(f"Database Error: {e}")


def load_profile(patient_id):
     try:
        conn = get_connection()
        query = "SELECT * FROM patient_profiles WHERE patient_id=%s"
        df = pd.read_sql(query, conn, params=[patient_id])
        conn.close()

        if len(df) > 0:
            return df.iloc[0].to_dict()
        return {}

     except:
        return {}
    # try:
    #     conn = get_connection()
    #     query = "SELECT * FROM patient_profiles WHERE patient_id=%s"
    #     df = pd.read_sql(query, conn, params=[patient_id])
    #     conn.close()

    #     if len(df) > 0:
    #         return df.iloc[0].to_dict()
    #     return {}

    # except:
    #     return {}    
    

# ================= RECOMMENDATIONS =================

def get_recommendations(predicted_class):
    if predicted_class=="malignant":
        return [
            "Consult endocrinologist immediately",
            "Fine needle biopsy recommended",
            "Advanced ultrasound screening required",
            "Thyroid hormone blood test required"
        ]
    elif predicted_class=="benign":
        return [
            "Routine monitoring required",
            "Follow up after 6 months",
            "Thyroid hormone test suggested"
        ]
    else:
        return [
            "Healthy thyroid condition",
            "Annual health checkup recommended"
        ]
    




# ================= VALIDATION FUNCTION =================
# def validate_ultrasound(image):
#     gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
#     mean_intensity = np.mean(gray)
#     edges = cv2.Canny(gray, 50, 150)
#     edge_ratio = np.sum(edges > 0) / edges.size

#     if mean_intensity > 200:
#         return False
#     if edge_ratio > 0.2:
#         return False
#     return True

def validate_ultrasound(image):
    gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)

    # 1. Color check (ultrasound is mostly grayscale)
    color_std = np.std(image[:,:,0] - image[:,:,1]) + np.std(image[:,:,1] - image[:,:,2])

    # 2. Texture check (ultrasound has grainy texture)
    laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()

    # 3. Edge density
    edges = cv2.Canny(gray, 50, 150)
    edge_ratio = np.sum(edges > 0) / edges.size

    # 4. Brightness check
    mean_intensity = np.mean(gray)

    # ===== STRICT CONDITIONS =====
    if color_std > 15:
        return False   # colorful image → reject

    if laplacian_var < 10:
        return False   # too smooth → reject

    if edge_ratio > 0.25:
        return False   # too many edges → reject

    if mean_intensity > 180:
        return False   # too bright → reject

    return True

# ================= PDF HELPERS =================
def add_page_border(canvas, doc):
    canvas.saveState()
    canvas.setLineWidth(2)
    canvas.rect(20, 20, A4[0] - 40, A4[1] - 40)
    canvas.restoreState()

def add_header(canvas, doc):
    canvas.saveState()
    canvas.setFillColor(colors.HexColor("#2563eb"))
    canvas.rect(0, A4[1] - 60, A4[0], 60, fill=1)
    canvas.setFillColor(colors.white)
    canvas.setFont("Helvetica-Bold", 14)
    canvas.drawString(40, A4[1] - 35, "AI-BASED THYROID DIAGNOSIS SYSTEM")
    canvas.setFont("Helvetica", 9)
    canvas.drawRightString(A4[0] - 40, A4[1] - 35, "Automated Medical Report")
    canvas.restoreState()

def add_watermark(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 50)
    canvas.setFillColorRGB(0.9, 0.9, 0.9)
    canvas.translate(300, 400)
    canvas.rotate(45)
    canvas.drawCentredString(0, 0, "AI DIAGNOSIS")
    canvas.restoreState()

# ================= MAIN PDF FUNCTION =================
def generate_pdf(predicted_class, confidence, stage, name, age, gender,
                 preds, class_labels, REPORT_FOLDER, logo_path=None):

    os.makedirs(REPORT_FOLDER, exist_ok=True)
    filename = os.path.join(
        REPORT_FOLDER,
        f"report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    )

    report_id = f"THY-{datetime.now().strftime('%Y%m%d%H%M%S')}"

    # QR CODE
    qr_data = f"""Report ID: {report_id}
Patient: {name}
Prediction: {predicted_class}
Confidence: {confidence:.2f}%
Date: {datetime.now().strftime('%d-%m-%Y')}"""

    qr_path = os.path.join(REPORT_FOLDER, "qr.png")
    qr = qrcode.make(qr_data)
    qr.save(qr_path)

    # CHART
    chart_path = os.path.join(REPORT_FOLDER, "chart.png")
    fig, ax = plt.subplots()
    ax.bar(class_labels, [float(p) * 100 for p in preds[0]])
    ax.set_title("Prediction Confidence")
    ax.set_ylabel("Confidence (%)")
    fig.tight_layout()
    fig.savefig(chart_path)
    plt.close(fig)

    # DOCUMENT
    doc = SimpleDocTemplate(filename, pagesize=A4)
    styles = getSampleStyleSheet()
    content = []

    if logo_path and os.path.exists(logo_path):
        content.append(RLImage(logo_path, width=1 * inch, height=1 * inch))
        content.append(Spacer(1, 10))

    content.append(Paragraph("<b>Medical Diagnosis Report</b>", styles['Title']))
    content.append(Spacer(1, 10))
    content.append(Paragraph(f"<b>Report ID:</b> {report_id}", styles['Normal']))
    content.append(Spacer(1, 15))

    patient_data = [
        ["Name", name],
        ["Age", age],
        ["Gender", gender],
        ["Date", datetime.now().strftime("%d %B %Y")]
    ]

    table = Table(patient_data, colWidths=[150, 300])
    table.setStyle(TableStyle([
        ("GRID", (0, 0), (-1, -1), 0.5, colors.black),
        ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey)
    ]))

    content.append(Paragraph("<b>Patient Details</b>", styles['Heading2']))
    content.append(Spacer(1, 10))
    content.append(table)
    content.append(Spacer(1, 20))

    diagnosis = f"""<b>Prediction:</b> {predicted_class}<br/>
<b>Confidence:</b> {confidence:.2f}%<br/>
<b>Stage:</b> {stage}"""

    content.append(Paragraph("<b>Diagnosis</b>", styles['Heading2']))
    content.append(Spacer(1, 10))
    content.append(Paragraph(diagnosis, styles['Normal']))
    content.append(Spacer(1, 20))

    table_data = [["Class", "Confidence (%)"]]
    for i, label in enumerate(class_labels):
        table_data.append([label, f"{preds[0][i] * 100:.2f}"])

    conf_table = Table(table_data)
    conf_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.darkblue),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.black)
    ]))

    content.append(Paragraph("<b>Confidence Analysis</b>", styles['Heading2']))
    content.append(Spacer(1, 10))
    content.append(conf_table)
    content.append(Spacer(1, 20))

    if os.path.exists(chart_path):
        content.append(Paragraph("<b>Visualization</b>", styles['Heading2']))
        content.append(Spacer(1, 10))
        content.append(RLImage(chart_path, width=400, height=250))
        content.append(Spacer(1, 20))

    if os.path.exists(qr_path):
        content.append(Paragraph("<b>QR Code</b>", styles['Heading2']))
        content.append(Spacer(1, 10))
        content.append(RLImage(qr_path, width=120, height=120))
        content.append(Spacer(1, 20))

    content.append(Paragraph("<b>Recommendations</b>", styles['Heading2']))
    content.append(Spacer(1, 10))

    recommendations = get_recommendations(predicted_class)
    for r in recommendations:
        content.append(Paragraph(f"• {r}", styles['Normal']))
    content.append(Spacer(1, 20))

    content.append(Paragraph(
        "<b>Disclaimer:</b> This AI-generated report is for informational purposes only.",
        styles['Italic']
    ))

    doc.build(
        content,
        onFirstPage=lambda c, d: (add_header(c, d), add_watermark(c, d), add_page_border(c, d)),
        onLaterPages=lambda c, d: (add_header(c, d), add_watermark(c, d), add_page_border(c, d))
    )
    return filename

# ================= SIDEBAR =================

st.sidebar.image(
    "https://cdn-icons-png.flaticon.com/512/3774/3774299.png",
    width=120
)

st.sidebar.title("AI Thyroid System")
# st.sidebar.title("Automated Thyroid Prediction From Ultrasound Images")

# page=st.sidebar.radio(
#     "Navigation",
#     ["Home","AI Diagnosis","Analytics Dashboard","About"]
# )
page=st.sidebar.radio(
    "Navigation",
    ["Register","Home","AI Diagnosis","Recommendations","Analytics Dashboard","About","Profile"]
)

st.sidebar.markdown("---")
st.sidebar.subheader("Model Info")
st.sidebar.write("CNN Model : InceptionV3 , Segnet")
st.sidebar.write("Image Size : 224 x 224")
st.sidebar.write("Framework : TensorFlow")
st.sidebar.markdown("---")

if model:
    st.sidebar.success("Model Loaded Successfully")


# ================= REGISTRATION PAGE =================
if page == "Register":

    st.markdown("""
    <div class="card">
    <h2 style="text-align:center;">Patient Registration</h2>
    </div>
    """, unsafe_allow_html=True)

    col1, col2 = st.columns(2)

    with col1:
        reg_name = st.text_input("Full Name")
        reg_age = st.number_input("Age", 1, 100, 25)

    with col2:
        reg_gender = st.radio("Gender", ["Male","Female","Other"], horizontal=True)
        reg_phone = st.text_input("Phone Number")

    reg_address = st.text_area("Address")

    if st.button("✅ Register Patient"):
        if not reg_name or not reg_phone:
            st.warning("⚠ Please fill all required fields")
        else:
            patient_id = generate_patient_id()

            # Save in session
            st.session_state.registered = True
            st.session_state.patient_id = patient_id
            st.session_state.name = reg_name
            st.session_state.age = reg_age
            st.session_state.gender = reg_gender

            st.success(f"🎉 Registration Successful! Your Patient ID: {patient_id}")

            st.markdown(f"""
            <div class="resultbox">
            <b>Patient ID:</b> {patient_id}<br>
            <b>Name:</b> {reg_name}<br>
            <b>Age:</b> {reg_age}<br>
            <b>Gender:</b> {reg_gender}
            </div>
            """, unsafe_allow_html=True)
if page=="Home":
    if not st.session_state.registered:
        st.warning("⚠ Please register first before accessing the system.")
        st.stop()

    st.markdown("""
    <div class="card">
    <h1 style="text-align:center; color:white !important; font-weight:900;">
    AI Thyroid Diagnosis System
    </h1>
    <p style="text-align:center; font-size:18px; color:white;">
    Deep Learning Based Ultrasound Detection Platform
    </p>
    </div>
    """,unsafe_allow_html=True)

    col1,col2,col3=st.columns(3)

    with col1:
        st.markdown("""
        <div class="feature">
        <h3>🔬 Smart Detection</h3>
        Upload ultrasound images and detect thyroid abnormalities using AI.
        </div>
        """,unsafe_allow_html=True)

    with col2:
        st.markdown("""
        <div class="feature">
        <h3>📊 Medical Analytics</h3>
        Visualize prediction statistics and model performance.
        </div>
        """,unsafe_allow_html=True)

    with col3:
        st.markdown("""
        <div class="feature">
        <h3>📄 AI Reports</h3>
        Generate automated diagnosis reports instantly.
        </div>
        """,unsafe_allow_html=True)
      

elif page=="AI Diagnosis":
    # st.header("AI Thyroid Diagnosis")
    st.markdown("""
    <h1 style="
    text-align:center;
    color:white;
    font-weight:900;
    font-size:38px;
    margin-bottom:20px;
    ">
    🧠 AI Thyroid Diagnosis
    </h1>
    """, unsafe_allow_html=True)

    st.markdown('<div class="section-title">Patient Information</div>', unsafe_allow_html=True)

    col1, col2, col3 = st.columns(3)
    with col1:
        name = st.text_input("Patient Name", st.session_state.get("name", ""))
    with col2:
        age = st.number_input("Age", 1, 100, int(st.session_state.get("age", 25)))
    with col3:
        gender = st.radio("Gender", ["Male","Female","Other"],
                  index=["Male","Female","Other"].index(st.session_state.get("gender","Male")),
                  horizontal=True)

    symptoms = st.text_area("Symptoms / Issues", height=90)
      
    st.markdown(f"""
        <div class="card">
        <b>Patient ID:</b> {st.session_state.get("patient_id","Not Registered")}
        </div>
        <p style="color:white; font-weight:900; font-size:18px;">
        📊 Image Details & Patient Info
        </p>
        """, unsafe_allow_html=True)  
    st.markdown('<div class="section-title">Upload Ultrasound Image</div>', unsafe_allow_html=True)
    uploaded_file = st.file_uploader("Upload Image", type=["jpg","png","jpeg"])
    valid_image = False

    if uploaded_file:
        file_bytes = np.asarray(bytearray(uploaded_file.read()), dtype=np.uint8)
        image = cv2.imdecode(file_bytes, 1)
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        # ===== DEBUG VALIDATION VALUES =====
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
        color_std = np.std(image[:,:,0] - image[:,:,1]) + np.std(image[:,:,1] - image[:,:,2])
        laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()
        edges = cv2.Canny(gray, 50, 150)
        edge_ratio = np.sum(edges > 0) / edges.size
        mean_intensity = np.mean(gray)

        # st.write("🧪 Validation Debug Info")
        # st.write("Color Variance:", color_std)
        # st.write("Texture (Laplacian):", laplacian_var)
        # st.write("Edge Ratio:", edge_ratio)
        # st.write("Mean Intensity:", mean_intensity)

        st.markdown("""
        <p style="color:white; font-weight:900; font-size:18px;">
        🧪 Validation Debug Info
        </p>
        """, unsafe_allow_html=True)

        st.markdown(f"""
        <div style="
        background: linear-gradient(135deg,#1e293b,#0f172a);
        padding:15px;
        border-radius:12px;
        color:white;
        font-weight:800;
        font-size:16px;
        line-height:1.8;
        box-shadow:0px 6px 20px rgba(0,0,0,0.4);
        ">

        🔹 Color Variance: <b>{color_std:.2f}</b> <br>
        🔹 Texture (Laplacian): <b>{laplacian_var:.2f}</b> <br>
        🔹 Edge Ratio: <b>{edge_ratio:.4f}</b> <br>
        🔹 Mean Intensity: <b>{mean_intensity:.2f}</b>

        </div>
        """, unsafe_allow_html=True)
        if not validate_ultrasound(image):
            # st.error("❌ Invalid Image! Please upload a valid thyroid ultrasound image.")
        #   st.error("❌ Invalid Image! Please upload a valid thyroid ultrasound image.")
           st.markdown("""
           <div style="
           background:#7f1d1d;
           padding:15px;
           border-radius:10px;
           color:white;
           font-weight:900;
           ">
           ⚠ Invalid Image: Please upload a thyroid ultrasound scan only.
           </div>
           """, unsafe_allow_html=True)
           st.stop()
        else:
            valid_image = True
            st.image(image, width=350)
            st.markdown(f"""
            <div style="
            background: linear-gradient(135deg,#1e3a8a,#2563eb);
            padding:20px;
            border-radius:15px;
            color:white;
            font-weight:900;
            font-size:17px;
            box-shadow:0px 8px 25px rgba(0,0,0,0.4);
            margin-top:15px;
            ">

           📁 File Name: {uploaded_file.name} <br><br>

           📏 Resolution: {image.shape[1]} x {image.shape[0]} <br><br>

           🧠 Ready for AI Analysis <br><br>

           🆔 Patient ID: {st.session_state.get("patient_id", "Not Registered")}

           </div>
           """, unsafe_allow_html=True)
            # st.markdown(f"""
            # <div class="card">
            # 📁 File Name: {uploaded_file.name} <br>
            # 📏 Resolution: {image.shape[1]} x {image.shape[0]} <br>
            # 🧠 Ready for AI Analysis
            # </div>
            # """, unsafe_allow_html=True)

    run = st.button("🚀 Run AI Diagnosis")

    if run:
        if not name:
            st.warning("⚠ Please enter patient name")
        elif not uploaded_file:
            st.warning("⚠ Please upload ultrasound image")
        elif not valid_image:
            st.warning("⚠ Please upload a valid ultrasound image")

    if uploaded_file and model and run and name and valid_image:
        st.markdown("""
        <p style="color:white; font-weight:900; font-size:18px;">
        🤖 AI analyzing ultrasound image...
        </p>
        """, unsafe_allow_html=True)

        with st.spinner("Processing..."):
            time.sleep(2)
            roi = cv2.resize(image, (224,224))
            input_img = np.expand_dims(roi/255.0, axis=0)
            preds = model.predict(input_img)

        pred_index = np.argmax(preds)
        predicted_class = class_labels[pred_index]
        st.session_state["last_prediction"] = predicted_class
        confidence = float(np.max(preds))*100

        save_prediction(
        st.session_state.get("patient_id"),
        uploaded_file.name,
        predicted_class,
        confidence
        )

        stage = "Cancer Risk" if predicted_class=="malignant" else \
                "Benign Nodule" if predicted_class=="benign" else \
                "Normal Tissue"
 # ================= AI EXPLANATION FUNCTION =================
        def generate_ai_explanation(predicted_class, confidence):

         if predicted_class.lower() == "malignant":
          return f"""
          The AI model detected strong abnormal patterns in the thyroid ultrasound image.
          These patterns are commonly associated with malignant tumors.

          A confidence score of {confidence:.2f}% indicates a high probability of cancerous tissue.

          Immediate medical consultation and further diagnostic tests like biopsy are highly recommended.
          """

         elif predicted_class.lower() == "benign":
          return f"""
          The AI model identified non-cancerous nodules in the thyroid gland.

          A confidence score of {confidence:.2f}% suggests that the condition is likely benign.

          Regular monitoring and follow-up scans are advised to ensure stability.
          """

         else:
          return f"""
          The AI model found no significant abnormalities in the thyroid ultrasound.

          A confidence score of {confidence:.2f}% indicates a normal thyroid condition.

          Maintaining routine health checkups is recommended.
          """
 # ===== PREDICTION RESULT =====
        st.markdown("""
        <h3 style="color:white; font-weight:900;">
        🤖 AI Diagnosis Report
        </h3>
        """, unsafe_allow_html=True)

        st.markdown(f"""
        <div style="
        background:#1e293b;
        padding:25px;
        border-radius:18px;
        color:white;
        font-weight:900;
        font-size:19px;
        ">
        <b>Prediction:</b> {predicted_class} <br>
        <b>Confidence:</b> {confidence:.2f}% <br>
        <b>Stage:</b> {stage}
        </div>
        """, unsafe_allow_html=True)
        # ================= EXPLAINABLE AI =================
    #     explanation = generate_ai_explanation(predicted_class, confidence)

    #     st.markdown("""
    #     <h3 style="color:white; font-weight:900;">
    #     🧠 Explainable AI Insight
    #     </h3>
    #     """, unsafe_allow_html=True)

    #     st.markdown(f"""
    #     <div style="
    #     background: linear-gradient(135deg,#0f172a,#1e293b);
    #     padding:20px;
    #     border-radius:15px;
    #     color:white;
    #     font-size:16px;
    #     line-height:1.6;
    #     box-shadow:0px 8px 20px rgba(0,0,0,0.4);
    #     margin-top:10px;
    #     ">
    #    {explanation}
    #    </div>
    #    """, unsafe_allow_html=True)
        # ================= EXPLAINABLE AI =================
        explanation = generate_ai_explanation(predicted_class, confidence)

        st.markdown("""
        <h3 style="color:white; font-weight:900;">
        🧠 Explainable AI Insight
        </h3>
        """, unsafe_allow_html=True)

        st.markdown(f"""
        <div style="
        background: linear-gradient(135deg,#0f172a,#1e293b);
        padding:20px;
        border-radius:15px;
        color:white;
        font-size:16px;
        line-height:1.6;
        box-shadow:0px 8px 20px rgba(0,0,0,0.4);
        margin-top:10px;
        ">
        {explanation}
        </div>
        """, unsafe_allow_html=True)


     # 🔥 Risk Score
        risk_score = 90 if predicted_class=="malignant" else 50 if predicted_class=="benign" else 10

        # st.markdown(f"""
        # <div style="
        # background:linear-gradient(135deg,#ef4444,#dc2626);
        # padding:20px;
        # border-radius:15px;
        # color:white;
        # font-size:20px;
        # font-weight:900;
        # text-align:center;
        # margin-top:15px;
        # ">
        # ⚠ Risk Score: {risk_score}%
        # 🔥 Risk Score + Color Logic
        if predicted_class.lower() == "malignant":
          risk_score = 90
          color = "#ef4444"   # 🔴 Red
        elif predicted_class.lower() == "benign":
          risk_score = 50
          color = "#f59e0b"   # 🟡 Yellow
        else:
          risk_score = 10
          color = "#22c55e"   # 🟢 Green

        # st.markdown(f"""
        # <div style="
        # background:linear-gradient(135deg,{color},{color});
        # padding:20px;
        # border-radius:15px;
        # color:white;
        # font-size:20px;
        # font-weight:900;
        # text-align:center;
        # margin-top:15px;
        # ">
        # ⚠ Risk Score: {risk_score}%
        # </div>
        # """, unsafe_allow_html=True)
        # ================= 🎯 SMART RISK LOGIC =================
        if predicted_class.lower() == "malignant":
          risk_score = 90
          color = "#ef4444"   # red
        elif predicted_class.lower() == "benign":
          risk_score = 50
          color = "#f59e0b"   # yellow
        else:
          risk_score = 10
          color = "#22c55e"   # green


# ================= 🎞️ 1. ANIMATED PROGRESS BAR =================
        # st.markdown("<h3 style='color:white;'>📊 Risk Analysis</h3>", unsafe_allow_html=True)

        # progress_bar = st.progress(0)
        # for i in range(risk_score + 1):
        #   time.sleep(0.01)
        # progress_bar.progress(i)


# # ================= 🟢 2. CIRCULAR PROGRESS =================
#         st.markdown(f"""
#           <div style="
#           display:flex;
#           justify-content:center;
#           margin-top:20px;
#           ">
#           <div style="
#           width:140px;
#           height:140px;
#           border-radius:50%;
#           background:conic-gradient({color} {risk_score}%, #1e293b {risk_score}%);
#           display:flex;
#           align-items:center;
#           justify-content:center;
#           color:white;
#           font-weight:900;
#           font-size:24px;
#           box-shadow:0px 10px 30px rgba(0,0,0,0.6);
#           ">
#           {risk_score}%
#           </div>
#           </div>
#           """, unsafe_allow_html=True)


# ================= 🎯 3. GAUGE METER =================

        fig, ax = plt.subplots(figsize=(3, 0.3))
        ax.barh([0], [risk_score], height=0.2)
        ax.set_xlim(0, 100)

        for spine in ax.spines.values():
          spine.set_visible(False)
# color logic
        if risk_score > 70:
          bar_color = "red"
        elif risk_score > 30:
          bar_color = "yellow"
        else:
          bar_color = "green"

        ax.barh([0], [risk_score], height=0.2)
        ax.set_xlim(0, 100)
        ax.set_yticks([])
        ax.set_title("Risk Meter")

# apply color AFTER drawing
        # for bar in ax.patches:
        #   bar.set_color(bar_color)
        plt.margins(0, 0)
        st.pyplot(fig)
        plt.tight_layout(pad=0.5)

        # 🔥 Confidence Bar
        st.progress(int(confidence))
        # st.write(f"Confidence Level: {confidence:.2f}%")
        st.markdown(f"""
        <p style="
        color:white;
        font-weight:900;
        font-size:18px;
        margin-top:10px;
        ">
        Confidence Level: {confidence:.2f}%
        </p>
        """, unsafe_allow_html=True)
        
        # Generate PDF and provide download button
        with st.spinner("📄 Generating Medical Report..."):
            pdf_path = generate_pdf(
                predicted_class, confidence, stage, name, age, gender, 
                preds, class_labels, REPORT_FOLDER
            )
            
            with open(pdf_path, "rb") as pdf_file:
                PDFbyte = pdf_file.read()

            st.markdown("<br>", unsafe_allow_html=True)
            st.download_button(
                label="📥 Download Diagnosis Report (PDF)",
                data=PDFbyte,
                file_name=f"Thyroid_Diagnosis_{name.replace(' ', '_')}.pdf",
                mime="application/pdf"
            )
# ================= PATIENT HISTORY =================
            st.markdown("""
            <h3 style="color:white; font-weight:900;">
            📜 Patient History
            </h3>
            """, unsafe_allow_html=True)

            # history_df = load_patient_history(st.session_state.get("patient_id"))
            history_df = load_patient_history(st.session_state.get("patient_id"))

            if len(history_df) > 0:
              st.dataframe(history_df)

    # ===== TREND GRAPH =====
            #   mapping = {"malignant": 2, "benign": 1, "normal": 0}
            #   history_df["trend"] = history_df["predicted_class"].map(mapping)

            #   fig, ax = plt.subplots()
            #   x = history_df["processed_at"]
            #   y = history_df["trend"]
            #   line, = ax.plot([], [], marker='o')
            #   def update(frame):
            #     line.set_data(x[:frame], y[:frame])
            #     return line,

            #   ani = animation.FuncAnimation(fig, update, frames=len(x)+1, interval=500)
            #   if len(x) > 1:
            #     ax.set_xlim(min(x), max(x))
            #     ax.set_ylim(-0.5, 2.5)

            #     ax.set_yticks([0,1,2])
            #     ax.set_yticklabels(["normal","benign","malignant"])
              
            #     ax.set_title("Diagnosis Trend Over Time")
            #     ax.set_xlabel("Date")
            #     ax.set_ylabel("Condition")

              
            #   plt.xticks(rotation=30)

            #   st.pyplot(fig)

            # else:
            #  st.info("No previous records found.")
            


            # if len(history_df) > 0:
            #   st.dataframe(history_df)
            # else:
            #   st.info("No previous records found.")      
            # 
elif page == "Recommendations":
    

    st.markdown("""
    <h1 style="
    text-align:center;
    color:white;
    font-weight:900;
    font-size:38px;
    margin-bottom:20px;
    ">
    💊 Smart Thyroid Recommendations
    </h1>
    """, unsafe_allow_html=True)

    st.markdown('<div class="section-title">Patient Assessment</div>', unsafe_allow_html=True)

    col1, col2, col3 = st.columns(3)

    with col1:
        age = st.number_input("Age", 1, 100, 25)

    with col2:
        gender = st.radio("Gender", ["Male", "Female", "Other"], horizontal=True)

    with col3:
        lifestyle = st.radio("Lifestyle", ["Healthy", "Moderate", "Unhealthy"], horizontal=True)

    st.markdown('<div class="section-title">Select Symptoms</div>', unsafe_allow_html=True)

    col1, col2 = st.columns(2)

    with col1:
        swelling = st.radio("Neck Swelling", ["No", "Mild", "Severe"], horizontal=True)
        fatigue = st.radio("Fatigue", ["No", "Yes"], horizontal=True)
        weight = st.radio("Weight Change", ["No", "Gain", "Loss"], horizontal=True)

    with col2:
        voice = st.radio("Voice Change", ["No", "Yes"], horizontal=True)
        pain = st.radio("Pain in Neck", ["No", "Yes"], horizontal=True)
        family_history = st.radio("Family History", ["No", "Yes"], horizontal=True)

    predicted_class = st.session_state.get("last_prediction", "normal")

    if st.button("🔍 Generate Recommendations"):

        recommendations = []
        risk_level = "Low"

        # ================= 🎯 AI PREDICTION =================
        if predicted_class == "malignant":
            recommendations.append("Immediate consultation with an endocrinologist is strongly recommended.")
            recommendations.append("Fine Needle Aspiration (FNA) biopsy is advised.")
            risk_level = "High"

        elif predicted_class == "benign":
            recommendations.append("Condition appears non-cancerous, but periodic monitoring is necessary.")
            recommendations.append("Follow-up ultrasound after 6 months.")
            risk_level = "Moderate"

        else:
            recommendations.append("No major abnormalities detected. Maintain a healthy lifestyle.")

        # ================= 🎯 SYMPTOMS =================
        if swelling == "Severe":
            recommendations.append("Severe swelling detected → Immediate ultrasound scan required.")
            risk_level = "High"

        if voice == "Yes":
            recommendations.append("Voice changes may indicate nerve involvement → ENT consultation suggested.")

        if pain == "Yes":
            recommendations.append("Persistent pain requires clinical examination.")

        if fatigue == "Yes":
            recommendations.append("Check thyroid hormone levels (TSH, T3, T4).")

        if weight != "No":
            recommendations.append("Weight changes indicate hormonal imbalance → Blood test recommended.")

        # ================= 🎯 LIFESTYLE =================
        if lifestyle == "Unhealthy":
            recommendations.append("Improve diet: Include iodine-rich foods (fish, dairy).")
            recommendations.append("Avoid processed and junk foods.")
            recommendations.append("Regular physical activity is recommended.")

        # ================= 🎯 FAMILY HISTORY =================
        if family_history == "Yes":
            recommendations.append("Family history present → Regular thyroid screening is important.")

        # ================= 🎯 AGE =================
        if age > 40:
            recommendations.append("Age above 40 → Annual thyroid screening advised.")

        # ================= 🎨 RISK COLOR =================
        if risk_level == "High":
            color = "#ef4444"
        elif risk_level == "Moderate":
            color = "#f59e0b"
        else:
            color = "#22c55e"

        # ================= 🎯 DISPLAY =================
        st.markdown(f"""
        <div style="
        background: linear-gradient(135deg,{color},{color});
        padding:20px;
        border-radius:15px;
        color:white;
        font-weight:900;
        font-size:18px;
        text-align:center;
        margin-top:15px;
        ">
        ⚠ Risk Level: {risk_level}
        </div>
        """, unsafe_allow_html=True)

        st.markdown('<div class="section-title">Personalized Recommendations</div>', unsafe_allow_html=True)

        for r in recommendations:
            st.markdown(f"""
            <div class="recbox">
            ✔ {r}
            </div>
            """, unsafe_allow_html=True)      

elif page == "Analytics Dashboard":
    st.header("Prediction Analytics")
    data = load_data()

    if len(data) > 0:
        st.dataframe(data)
        counts = data["predicted_class"].value_counts()

        fig, ax = plt.subplots(figsize=(7, 4))
        ax.bar(counts.index, counts.values, color=["#ef4444", "#f59e0b", "#22c55e"])
        ax.set_title("Prediction Distribution", fontsize=14)
        ax.set_xlabel("Prediction Class")
        ax.set_ylabel("Number of Cases")
        plt.xticks(rotation=90)
        ax.tick_params(axis='x', labelsize=8)
        st.pyplot(fig)

        st.markdown("""
        <hr>
        <div style="
        background:linear-gradient(135deg,#2563eb,#06b6d4);
        padding:25px;
        border-radius:18px;
        box-shadow:0px 10px 25px rgba(0,0,0,0.35);
        color:white;
        font-size:18px;
        ">
        <h3 style="color:white;">Model Performance</h3>
        <p><b>Accuracy :</b> 94%</p>
        <p><b>Precision :</b> 92%</p>
        <p><b>Recall :</b> 91%</p>
        <p><b>F1 Score :</b> 92%</p>
        </div>
        """, unsafe_allow_html=True)
    else:
        st.warning("No prediction data available yet.")
#     page=st.sidebar.radio(
#     "Navigation",
#     ["Register","Home","AI Diagnosis","Recommendations","Analytics Dashboard","Profile","About"]
# )        

elif page == "About":
    st.markdown("""
    <style>
    .stApp{
        background:
        linear-gradient(rgba(0,0,0,0.6),rgba(0,0,0,0.6)),
        # url("https://images.unsplash.com/photo-1582719478250-c89cae4dc85b");
        url("https://share.google/lonb3ALYwl94gLmk1");
        background-size:cover;
        background-attachment:fixed;
    }
    </style>
    """, unsafe_allow_html=True)

    st.markdown("""
    <div class="feature" style="padding:35px; margin-bottom:25px; height:auto;">
    <h2 style="color:black; font-weight:900;">About This Project</h2>
    <p style="color:white; font-size:17px;">
    AI Thyroid Diagnosis System uses deep learning models like 
    <b>SegNet</b> and <b>InceptionV3</b> to analyze thyroid ultrasound 
    images and assist doctors in early thyroid disease detection.
    </p>
    <p style="color:white; font-size:17px;">
    The system provides an automated AI-powered platform that helps
    improve diagnosis speed, accuracy, and medical decision support.
    </p>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("""
    <div class="feature" style="padding:35px; margin-bottom:25px; height:auto;">
    <h3 style="color:black; font-weight:900;">Technologies Used</h3>
    <ul style="color:white; text-align:left; font-size:17px;">
    <li>TensorFlow / Keras Deep Learning Framework</li>
    <li>OpenCV for Medical Image Processing</li>
    <li>Streamlit Web Interface</li>
    <li>MySQL Database for Prediction Storage</li>
    <li>Python Scientific Computing Stack</li>
    </ul>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("""
    <div class="feature" style="padding:35px; height:auto;">
    <h3 style="color:black; font-weight:900;">Key Features</h3>
    <ul style="color:white; text-align:left; font-size:17px;">
    <li>AI-based Thyroid Ultrasound Image Segmentation</li>
    <li>Region of Interest (ROI) Extraction</li>
    <li>CNN Classification using InceptionV3</li>
    <li>Automated Medical PDF Report Generation</li>
    <li>Prediction Analytics Dashboard</li>
    <li>Patient Information Collection</li>
    <li>Medical Recommendation System</li>
    </ul>
    </div>
    """, unsafe_allow_html=True)

# ================= FOOTER =================
    st.markdown("""
    <hr>
    <p style="color:white; text-align:center;">
    AI Thyroid Diagnosis System<br>
    Deep Learning for Medical Imaging
    </p>
    """, unsafe_allow_html=True)


elif page == "Profile":
    patient_id = st.session_state.get("patient_id")
    profile_data = load_profile(patient_id)

    st.markdown("""
    <h1 style="
    text-align:center;
    color:white;
    font-weight:900;
    font-size:36px;
    margin-bottom:20px;
    ">
     Patient Profile & Settings
    </h1>
    """, unsafe_allow_html=True)
    st.markdown("""
    <div style="text-align:center;">
    <img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
         style="width:110px; border-radius:50%; box-shadow:0px 6px 20px rgba(0,0,0,0.5);">
    </div>
    """, unsafe_allow_html=True)

    st.markdown('<div class="section-title">Patient Information</div>', unsafe_allow_html=True)

    # ================= LOAD EXISTING DATA =================
    # name = st.session_state.get("name", "")
    # age = st.session_state.get("age", 25)
    # gender = st.session_state.get("gender", "Male")
    name = profile_data.get("name", st.session_state.get("name", ""))
    age = profile_data.get("age", st.session_state.get("age", 25))
    gender = profile_data.get("gender", st.session_state.get("gender", "Male"))

    col1, col2 = st.columns(2)

    with col1:
        new_name = st.text_input("Full Name", name)
        new_age = st.number_input("Age", 1, 100, age)

    with col2:
        new_gender = st.radio("Gender", ["Male","Female","Other"],
                              index=["Male","Female","Other"].index(gender),
                              horizontal=True)

    st.markdown('<div class="section-title">Preferences</div>', unsafe_allow_html=True)

    col1, col2 = st.columns(2)

    with col1:
        theme = st.selectbox("Theme Mode", ["Dark", "Light"])
    with col2:
        notifications = st.radio("Notifications", ["Enabled","Disabled"], horizontal=True)

    # ================= SAVE BUTTON =================
    # if st.button("💾 Save Changes"):

        st.session_state["name"] = new_name
        st.session_state["age"] = new_age
        st.session_state["gender"] = new_gender
        st.session_state["theme"] = theme
        st.session_state["notifications"] = notifications

    #     st.success("✅ Profile updated successfully!")
        if st.button("💾 Save Changes", key="profile_save_btn"):
          save_profile(
          patient_id,
          new_name,
          new_age,
          new_gender,
          theme,
          notifications
    )
    st.success("✅ Profile saved to database!")

    # ================= DISPLAY PROFILE CARD =================
    st.markdown('<div class="section-title">Profile Summary</div>', unsafe_allow_html=True)

    st.markdown(f"""
    <div style="
    background: linear-gradient(135deg,#1e3a8a,#2563eb);
    padding:25px;
    border-radius:18px;
    color:white;
    font-size:17px;
    box-shadow:0px 10px 25px rgba(0,0,0,0.4);
    margin-top:10px;
    ">

    <b>👤 Name:</b> {st.session_state.get("name","-")} <br><br>
    <b>🎂 Age:</b> {st.session_state.get("age","-")} <br><br>
    <b>⚧ Gender:</b> {st.session_state.get("gender","-")} <br><br>
    <b>🎨 Theme:</b> {st.session_state.get("theme","Dark")} <br><br>
    <b>🔔 Notifications:</b> {st.session_state.get("notifications","Enabled")}

    </div>
    """, unsafe_allow_html=True)


