import mysql.connector

# Connect to MySQL
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",   # replace with your MySQL password
    database="thyroid_ai"
)

cursor = conn.cursor()

# Insert test data
query = """
INSERT INTO prediction_results 
(image_name, predicted_class, confidence, model_name, segmentation_used)
VALUES (%s, %s, %s, %s, %s)
"""

values = ("test_image.jpg", "Benign", 0.94, "InceptionV3", True)

cursor.execute(query, values)
conn.commit()

print("Data inserted successfully!")

cursor.close()
conn.close()