
# # ==========================================================
# # AI THYROID DIAGNOSIS PIPELINE
# # Segmentation → ROI → Classification → Metrics → PDF Report
# # ==========================================================

# import os
# import random
# import cv2
# import numpy as np
# import tensorflow as tf
# import matplotlib.pyplot as plt
# import seaborn as sns

# from datetime import datetime

# from sklearn.metrics import confusion_matrix
# from sklearn.metrics import classification_report
# from sklearn.metrics import f1_score
# from sklearn.metrics import roc_curve, auc
# from sklearn.preprocessing import label_binarize

# import pymysql

# from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
# from reportlab.platypus import Image, Table, TableStyle, PageBreak
# from reportlab.lib.styles import getSampleStyleSheet
# from reportlab.lib import colors

# print("\n========== AI THYROID DIAGNOSIS PIPELINE ==========\n")

# # ================= PATHS =================

# BASE_PATH = r"C:\Users\ELCOT\Desktop\project"

# DATASET_PATH = os.path.join(
#     BASE_PATH,
#     "Thyroid Classification Dataset1",
#     "Thyroid Classification Dataset1"
# )

# MODEL_PATH = os.path.join(
#     BASE_PATH,
#     "saved_models",
#     "thyroid_inception_multiscale.h5"
# )

# REPORT_PATH = os.path.join(BASE_PATH, "reports")

# os.makedirs(REPORT_PATH, exist_ok=True)

# MODEL_NAME = "InceptionV3"
# MODEL_VERSION = "v1.0"

# # ================= LOAD MODEL =================

# print("Loading Model...")
# model = tf.keras.models.load_model(MODEL_PATH)
# print("Model Loaded Successfully\n")

# # ================= AUTO DETECT CLASSES =================

# classes = [d for d in os.listdir(DATASET_PATH)
#            if os.path.isdir(os.path.join(DATASET_PATH, d))]

# print("Detected Dataset Classes:", classes)

# class_indices = {cls: i for i, cls in enumerate(classes)}
# inv_map = {v: k for k, v in class_indices.items()}

# NUM_CLASSES = len(classes)

# # ================= MYSQL CONNECTION =================

# MYSQL_HOST = "localhost"
# MYSQL_USER = "root"
# MYSQL_PASSWORD = "root"
# MYSQL_DB = "thyroid_ai"

# try:

#     conn = pymysql.connect(
#         host=MYSQL_HOST,
#         user=MYSQL_USER,
#         password=MYSQL_PASSWORD,
#         database=MYSQL_DB
#     )

#     cursor = conn.cursor()

#     print("MySQL Connected Successfully\n")

# except Exception as e:

#     print("MySQL Error:", e)

#     cursor = None

# # ================= IMAGE SELECTION =================

# print("1 → Random Image From Dataset")
# print("2 → Enter Image Path")

# option = input("Enter option: ").strip()

# if option == "1":

#     images = []

#     for root, dirs, files in os.walk(DATASET_PATH):

#         for f in files:

#             if f.lower().endswith((".jpg", ".jpeg", ".png")):
#                 images.append(os.path.join(root, f))

#     image_path = random.choice(images)

# else:

#     image_path = input("Enter full image path: ")

# print("\nSelected Image:", image_path)

# image_name = os.path.basename(image_path)

# # ================= LOAD IMAGE =================

# img = cv2.imread(image_path)

# if img is None:

#     print("Error loading image")
#     exit()

# original = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

# # ================= SEGMENTATION =================

# gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# blur = cv2.GaussianBlur(gray, (5, 5), 0)

# _, mask = cv2.threshold(
#     blur,
#     0,
#     255,
#     cv2.THRESH_BINARY + cv2.THRESH_OTSU
# )

# segmented = cv2.bitwise_and(original, original, mask=mask)

# # ================= ROI EXTRACTION =================

# contours, _ = cv2.findContours(
#     mask,
#     cv2.RETR_EXTERNAL,
#     cv2.CHAIN_APPROX_SIMPLE
# )

# if contours:

#     c = max(contours, key=cv2.contourArea)

#     x, y, w, h = cv2.boundingRect(c)

#     roi = original[y:y+h, x:x+w]

# else:

#     roi = original

# roi = cv2.resize(roi, (224, 224))

# # ================= CLASSIFICATION =================

# input_img = roi.astype(np.float32) / 255.0

# input_img = np.expand_dims(input_img, axis=0)

# pred = model.predict(input_img, verbose=0)

# pred_index = np.argmax(pred)

# predicted_class = inv_map[pred_index]

# confidence = float(np.max(pred)) * 100

# print("\nPrediction:", predicted_class)
# print("Confidence:", confidence)

# # ================= PERFORMANCE METRICS =================

# print("\nCalculating Performance Metrics...")

# y_true = []
# y_pred = []
# y_prob = []

# for cls in classes:

#     folder = os.path.join(DATASET_PATH, cls)

#     files = os.listdir(folder)[:50]

#     for f in files:

#         path = os.path.join(folder, f)

#         im = cv2.imread(path)

#         if im is None:
#             continue

#         im = cv2.resize(im, (224, 224))

#         im = im.astype(np.float32) / 255.0

#         im = np.expand_dims(im, 0)

#         p = model.predict(im, verbose=0)

#         y_true.append(class_indices[cls])
#         y_pred.append(np.argmax(p))
#         y_prob.append(p[0])

# # ================= CONFUSION MATRIX =================

# cm = confusion_matrix(y_true, y_pred)

# plt.figure(figsize=(6,5))

# sns.heatmap(cm, annot=True, cmap="Blues")

# plt.title("Confusion Matrix")

# cm_path = os.path.join(REPORT_PATH, "confusion_matrix.png")

# plt.savefig(cm_path)

# plt.close()

# # ================= ROC CURVE =================

# y_true_bin = label_binarize(y_true, classes=range(NUM_CLASSES))

# y_prob = np.array(y_prob)

# plt.figure()

# for i in range(NUM_CLASSES):

#     fpr, tpr, _ = roc_curve(y_true_bin[:, i], y_prob[:, i])

#     roc_auc = auc(fpr, tpr)

#     plt.plot(fpr, tpr, label=f"{inv_map[i]} (AUC={roc_auc:.2f})")

# plt.legend()

# plt.title("ROC Curve")

# roc_path = os.path.join(REPORT_PATH, "roc_curve.png")

# plt.savefig(roc_path)

# plt.close()

# # ================= F1 SCORE =================

# f1 = f1_score(y_true, y_pred, average="weighted")

# report_text = classification_report(y_true, y_pred, target_names=classes)

# print("F1 Score:", f1)

# # ================= SAVE IMAGES =================

# orig_path = os.path.join(REPORT_PATH, "original.png")
# seg_path = os.path.join(REPORT_PATH, "segmentation.png")
# roi_path = os.path.join(REPORT_PATH, "roi.png")

# cv2.imwrite(orig_path, cv2.cvtColor(original, cv2.COLOR_RGB2BGR))
# cv2.imwrite(seg_path, cv2.cvtColor(segmented, cv2.COLOR_RGB2BGR))
# cv2.imwrite(roi_path, cv2.cvtColor(roi, cv2.COLOR_RGB2BGR))

# # ================= MYSQL STORAGE =================

# if cursor:

#     try:

#         sql = """
#         INSERT INTO prediction_results
#         (image_name,predicted_class,confidence,model_name,model_version,image_path)
#         VALUES (%s,%s,%s,%s,%s,%s)
#         """

#         cursor.execute(sql, (
#             image_name,
#             predicted_class,
#             confidence,
#             MODEL_NAME,
#             MODEL_VERSION,
#             image_path
#         ))

#         conn.commit()

#         print("Stored in MySQL")

#     except Exception as e:

#         print("MySQL Error:", e)

# # ================= PDF REPORT =================

# report_file = os.path.join(
#     REPORT_PATH,
#     f"thyroid_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
# )

# styles = getSampleStyleSheet()

# story = []

# story.append(Paragraph("AI THYROID DIAGNOSIS REPORT", styles['Title']))

# story.append(Spacer(1,20))

# table_data = [

# ["Image Name", image_name],
# ["Predicted Class", predicted_class],
# ["Confidence", f"{confidence:.2f}%"],
# ["Model", MODEL_NAME],
# ["Date", str(datetime.now())]

# ]

# table = Table(table_data)

# table.setStyle(TableStyle([
# ('GRID',(0,0),(-1,-1),1,colors.black)
# ]))

# story.append(table)

# story.append(Spacer(1,20))

# story.append(Paragraph("Image Analysis", styles['Heading2']))

# story.append(Image(orig_path, width=250, height=180))
# story.append(Image(seg_path, width=250, height=180))
# story.append(Image(roi_path, width=250, height=180))

# story.append(PageBreak())

# story.append(Paragraph("Model Performance Metrics", styles['Title']))

# story.append(Paragraph(f"F1 Score: {f1}", styles['Normal']))

# story.append(Image(cm_path, width=400, height=300))
# story.append(Image(roc_path, width=400, height=300))

# for line in report_text.split("\n"):
#     story.append(Paragraph(line, styles['Normal']))

# pdf = SimpleDocTemplate(report_file)

# pdf.build(story)

# print("Professional Report Generated:", report_file)

# # ================= DASHBOARD =================

# plt.figure(figsize=(12,4))

# plt.subplot(1,3,1)
# plt.imshow(original)
# plt.title("Original Image")
# plt.axis("off")

# plt.subplot(1,3,2)
# plt.imshow(segmented)
# plt.title("Segmentation")
# plt.axis("off")

# plt.subplot(1,3,3)
# plt.imshow(roi)
# plt.title(f"Prediction: {predicted_class} ({confidence:.2f}%)")
# plt.axis("off")

# plt.show()

# print("\n========== PIPELINE COMPLETE ==========\n")

# if cursor:
#     cursor.close()

# if 'conn' in locals():
#     conn.close()


# # ==========================================================
# # AI THYROID DIAGNOSIS PIPELINE
# # Segmentation → ROI → Classification → Metrics → PDF Report
# # ==========================================================
# import os
# import cv2
# import random
# import numpy as np
# import matplotlib.pyplot as plt
# import seaborn as sns
# from datetime import datetime

# from tensorflow.keras.models import load_model
# from sklearn.metrics import confusion_matrix, classification_report, roc_curve, auc
# from sklearn.preprocessing import label_binarize

# from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, Table
# from reportlab.lib.styles import getSampleStyleSheet
# from reportlab.lib.pagesizes import A4

# print("\n========== AI THYROID DIAGNOSIS PIPELINE ==========\n")

# # ----------------------------------------------------
# # PATHS
# # ----------------------------------------------------

# BASE_PATH = r"C:\Users\ELCOT\Desktop\project"

# MODEL_PATH = r"C:\Users\ELCOT\Desktop\project\saved_models\thyroid_inceptionv3_model.h5"
# DATASET_PATH = os.path.join(BASE_PATH,"Thyroid Classification Dataset1","Thyroid Classification Dataset1")
# REPORT_FOLDER = os.path.join(BASE_PATH,"reports")

# os.makedirs(REPORT_FOLDER, exist_ok=True)

# # ----------------------------------------------------
# # LOAD MODEL
# # ----------------------------------------------------

# print("Loading Model...")

# model = load_model(MODEL_PATH)

# print("Model Loaded Successfully\n")

# classes = ["benign", "malignant", "normal"]

# class_indices = {
#     "benign":0,
#     "malignant":1,
#     "normal":2
# }

# print("Detected Classes:", classes)

# # ----------------------------------------------------
# # SEGMENTATION
# # ----------------------------------------------------

# def segment_thyroid(img):

#     gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

#     blur = cv2.GaussianBlur(gray,(5,5),0)

#     _,thresh = cv2.threshold(
#         blur,0,255,
#         cv2.THRESH_BINARY + cv2.THRESH_OTSU
#     )

#     kernel = np.ones((3,3),np.uint8)

#     opening = cv2.morphologyEx(
#         thresh,
#         cv2.MORPH_OPEN,
#         kernel,
#         iterations=2
#     )

#     return opening

# # ----------------------------------------------------
# # ROI EXTRACTION
# # ----------------------------------------------------

# def extract_roi(image, mask):

#     contours,_ = cv2.findContours(
#         mask,
#         cv2.RETR_EXTERNAL,
#         cv2.CHAIN_APPROX_SIMPLE
#     )

#     if len(contours) == 0:
#         return image

#     c = max(contours, key=cv2.contourArea)

#     x,y,w,h = cv2.boundingRect(c)

#     roi = image[y:y+h, x:x+w]

#     return roi

# # ----------------------------------------------------
# # PREPROCESS
# # ----------------------------------------------------

# def preprocess(img):

#     img = cv2.resize(img,(224,224))

#     img = img.astype("float32") / 255.0

#     img = np.expand_dims(img,0)

#     return img

# # ----------------------------------------------------
# # IMAGE INPUT
# # ----------------------------------------------------

# print("\n1 → Random Dataset Image")
# print("2 → Enter Image Path")

# option = input("Enter option: ")

# if option == "1":

#     selected_class = random.choice(classes)

#     class_folder = os.path.join(DATASET_PATH, selected_class)

#     image_file = random.choice(os.listdir(class_folder))

#     image_path = os.path.join(class_folder, image_file)

# else:

#     image_path = input("Enter image path: ")

# print("Selected Image:", image_path)

# # ----------------------------------------------------
# # LOAD IMAGE
# # ----------------------------------------------------

# image = cv2.imread(image_path)

# if image is None:
#     print("ERROR: Image not found")
#     exit()

# # ----------------------------------------------------
# # SEGMENT + ROI
# # ----------------------------------------------------

# mask = segment_thyroid(image)

# roi = extract_roi(image, mask)

# # ----------------------------------------------------
# # CLASSIFICATION
# # ----------------------------------------------------

# input_img = preprocess(roi)

# prediction_prob = model.predict(input_img)

# pred_class = np.argmax(prediction_prob)

# confidence = float(np.max(prediction_prob)) * 100

# prediction = classes[pred_class]

# print("\nPrediction:", prediction)
# print("Confidence:", confidence)

# # ----------------------------------------------------
# # DASHBOARD VISUALIZATION
# # ----------------------------------------------------

# fig,ax = plt.subplots(1,4,figsize=(15,4))

# ax[0].imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
# ax[0].set_title("Original Image")

# ax[1].imshow(mask, cmap="gray")
# ax[1].set_title("Segmented")

# ax[2].imshow(cv2.cvtColor(roi, cv2.COLOR_BGR2RGB))
# ax[2].set_title("ROI Extracted")

# ax[3].imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
# ax[3].set_title(f"{prediction}\n{confidence:.2f}%")

# for a in ax:
#     a.axis("off")

# plt.show()

# # ----------------------------------------------------
# # METRIC CALCULATION
# # ----------------------------------------------------

# print("\nCalculating Performance Metrics...\n")

# y_true = []
# y_pred = []
# y_prob = []

# for cls in classes:

#     folder = os.path.join(DATASET_PATH, cls)

#     if not os.path.exists(folder):
#         continue

#     files = os.listdir(folder)[:10]

#     for file in files:

#         path = os.path.join(folder, file)

#         img = cv2.imread(path)

#         if img is None:
#             continue

#         img = cv2.resize(img,(224,224))

#         img = img.astype("float32")/255.0

#         img = np.expand_dims(img,0)

#         p = model.predict(img, verbose=0)

#         y_true.append(class_indices[cls])

#         y_pred.append(np.argmax(p))

#         y_prob.append(p[0])

# # ----------------------------------------------------
# # CONFUSION MATRIX
# # ----------------------------------------------------

# cm = confusion_matrix(y_true, y_pred)

# plt.figure(figsize=(6,5))

# sns.heatmap(
#     cm,
#     annot=True,
#     fmt="d",
#     cmap="Blues",
#     xticklabels=classes,
#     yticklabels=classes
# )

# plt.title("Confusion Matrix")

# cm_path = os.path.join(REPORT_FOLDER,"confusion_matrix.png")

# plt.savefig(cm_path)

# plt.show()

# # ----------------------------------------------------
# # ROC CURVE
# # ----------------------------------------------------

# y_true_bin = label_binarize(y_true, classes=[0,1,2])

# y_prob = np.array(y_prob)

# plt.figure()

# for i in range(3):

#     fpr, tpr, _ = roc_curve(y_true_bin[:,i], y_prob[:,i])

#     roc_auc = auc(fpr,tpr)

#     plt.plot(fpr, tpr, label=f"{classes[i]} (AUC={roc_auc:.2f})")

# plt.plot([0,1],[0,1],'k--')

# plt.legend()

# plt.title("ROC Curve")

# roc_path = os.path.join(REPORT_FOLDER,"roc_curve.png")

# plt.savefig(roc_path)

# plt.show()

# # ----------------------------------------------------
# # CLASSIFICATION REPORT
# # ----------------------------------------------------

# report = classification_report(
#     y_true,
#     y_pred,
#     target_names=classes
# )

# print(report)

# # ----------------------------------------------------
# # SAVE IMAGES
# # ----------------------------------------------------

# orig_path = os.path.join(REPORT_FOLDER,"original.png")
# seg_path = os.path.join(REPORT_FOLDER,"segmented.png")
# roi_path = os.path.join(REPORT_FOLDER,"roi.png")

# cv2.imwrite(orig_path,image)
# cv2.imwrite(seg_path,mask)
# cv2.imwrite(roi_path,roi)

# # ----------------------------------------------------
# # GENERATE PDF REPORT
# # ----------------------------------------------------

# print("\nGenerating Professional PDF Report...\n")

# pdf_path = os.path.join(REPORT_FOLDER,"thyroid_diagnosis_report.pdf")

# styles = getSampleStyleSheet()

# elements = []

# elements.append(Paragraph(
# "AI Thyroid Ultrasound Diagnosis Report",
# styles["Title"]
# ))

# elements.append(Spacer(1,20))

# data = [

# ["Prediction", prediction],

# ["Confidence", f"{confidence:.2f}%"],

# ["Date", datetime.now().strftime("%Y-%m-%d %H:%M")]

# ]

# table = Table(data)

# elements.append(table)

# elements.append(Spacer(1,20))

# elements.append(Paragraph("Image Analysis",styles["Heading2"]))

# elements.append(Image(orig_path,width=400,height=250))
# elements.append(Image(seg_path,width=400,height=250))
# elements.append(Image(roi_path,width=400,height=250))

# elements.append(Spacer(1,20))

# elements.append(Paragraph("Confusion Matrix",styles["Heading2"]))

# elements.append(Image(cm_path,width=400,height=300))

# elements.append(Spacer(1,20))

# elements.append(Paragraph("ROC Curve",styles["Heading2"]))

# elements.append(Image(roc_path,width=400,height=300))

# elements.append(Spacer(1,20))

# elements.append(Paragraph("Classification Report",styles["Heading2"]))

# elements.append(Paragraph(f"<pre>{report}</pre>",styles["Normal"]))

# doc = SimpleDocTemplate(pdf_path,pagesize=A4)

# doc.build(elements)

# print("Report Saved At:", pdf_path)

# print("\n========== PIPELINE COMPLETED ==========")


# # ==========================================================
# # COMPLETE THYROID AI PIPELINE
# # Segmentation → ROI → Classification
# # Random OR Manual Image Selection
# # Professional Visual Output + Metrics
# # ==========================================================

# import os
# import random
# import cv2
# import numpy as np
# import matplotlib.pyplot as plt
# from sklearn.metrics import confusion_matrix, classification_report, accuracy_score

# from segmentation import segment_image
# from roi import extract_roi
# from classification import predict_image


# # ==========================================================
# # PROJECT ROOT
# # ==========================================================

# BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# PROJECT_ROOT = os.path.abspath(os.path.join(BASE_DIR, ".."))


# # ==========================================================
# # SAFE ARRAY CONVERSION (Fix read-only numpy error)
# # ==========================================================

# def safe_array(img):

#     if img is None:
#         return None

#     if isinstance(img, np.ndarray):
#         return np.array(img).copy()

#     return img


# # ==========================================================
# # SAFE IMAGE LOADER
# # ==========================================================

# def load_image_safe(image_input):

#     if image_input is None:
#         return None

#     if isinstance(image_input, np.ndarray):
#         return np.array(image_input).copy()

#     if isinstance(image_input, str):
#         if os.path.exists(image_input):
#             img = cv2.imread(image_input)
#             return np.array(img).copy()

#     return None


# # ==========================================================
# # PROFESSIONAL VISUALIZATION
# # ==========================================================

# def show_visual_results(original, segmented, roi, prediction, confidence):

#     original_img = load_image_safe(original)
#     segmented_img = load_image_safe(segmented)
#     roi_img = load_image_safe(roi)

#     if original_img is not None:
#         original_img = cv2.cvtColor(original_img, cv2.COLOR_BGR2RGB)

#     if segmented_img is not None:
#         segmented_img = cv2.cvtColor(segmented_img, cv2.COLOR_BGR2RGB)

#     if roi_img is not None:
#         roi_img = cv2.cvtColor(roi_img, cv2.COLOR_BGR2RGB)

#     # Clinical stage explanation
#     stage_description = {
#         "normal thyroid": "Healthy Thyroid Tissue (No Abnormality)",
#         "benign": "Benign Thyroid Nodule (Non-Cancerous)",
#         "Malignant": "Malignant Thyroid Tumor (Possible Cancer)"
#     }

#     stage_text = stage_description.get(prediction, "Unknown")

#     # Professional visualization
#     plt.figure(figsize=(14,6))

#     plt.subplot(1,3,1)
#     plt.imshow(original_img)
#     plt.title("Original Ultrasound")
#     plt.axis("off")

#     plt.subplot(1,3,2)
#     plt.imshow(segmented_img)
#     plt.title("AI Segmentation")
#     plt.axis("off")

#     plt.subplot(1,3,3)
#     plt.imshow(roi_img)
#     plt.title("Extracted ROI")
#     plt.axis("off")

#     plt.suptitle(
#         f"AI THYROID DIAGNOSIS SYSTEM\n"
#         f"Prediction: {prediction} | Confidence: {round(confidence*100,2)}%\n"
#         f"Clinical Stage: {stage_text}",
#         fontsize=14,
#         fontweight="bold"
#     )

#     plt.tight_layout()
#     plt.show()

#     print("\n========== AI DIAGNOSIS REPORT ==========")
#     print("Predicted Class :", prediction)
#     print("Confidence      :", round(confidence*100,2), "%")
#     print("Clinical Stage  :", stage_text)


# # ==========================================================
# # PERFORMANCE METRICS
# # ==========================================================

# def show_metrics(true_label, predicted_label):

#     y_true = [true_label]
#     y_pred = [predicted_label]

#     print("\n========== PERFORMANCE METRICS ==========")

#     print("Accuracy:", accuracy_score(y_true, y_pred))

#     print("\nClassification Report:\n")
#     print(classification_report(y_true, y_pred, zero_division=0))

#     print("Confusion Matrix:\n")
#     print(confusion_matrix(y_true, y_pred))


# # ==========================================================
# # FULL PIPELINE
# # ==========================================================

# def run_full_pipeline(image_path):

#     print("\n Step 1: Running Segmentation...")
#     segmented_output = segment_image(image_path)

#     segmented_output = safe_array(segmented_output)

#     print(" Step 2: Extracting ROI...")
#     roi_output = extract_roi(segmented_output)

#     roi_output = safe_array(roi_output)

#     print(" Step 3: Running Classification...")

#     roi_output = np.array(roi_output).copy()

#     prediction, confidence = predict_image(roi_output)

#     show_visual_results(
#         image_path,
#         segmented_output,
#         roi_output,
#         prediction,
#         confidence
#     )

#     return prediction, confidence


# # ==========================================================
# # RANDOM IMAGE SELECTION
# # ==========================================================

# def get_random_image():

#     DATASET_PATH = os.path.join(
#         PROJECT_ROOT,
#         "Thyroid Classification Dataset1",
#         "Thyroid Classification Dataset1"
#     )

#     if not os.path.exists(DATASET_PATH):
#         raise FileNotFoundError("Dataset folder not found!")

#     class_folders = [
#         folder for folder in os.listdir(DATASET_PATH)
#         if os.path.isdir(os.path.join(DATASET_PATH, folder))
#     ]

#     random_class = random.choice(class_folders)

#     class_path = os.path.join(DATASET_PATH, random_class)

#     images = [
#         img for img in os.listdir(class_path)
#         if img.lower().endswith(('.png','.jpg','.jpeg'))
#     ]

#     random_image = random.choice(images)

#     image_path = os.path.join(class_path, random_image)

#     print("Selected Image:", image_path)
#     print("Actual Class (Ground Truth):", random_class)

#     return image_path, random_class


# # ==========================================================
# # MAIN EXECUTION
# # ==========================================================

# if __name__ == "__main__":

#     print("\nSelect Input Option:")
#     print("1 → Use Random Image From Dataset")
#     print("2 → Enter Image Path Manually")

#     option = input("Enter option (1 or 2): ")

#     if option == "1":

#         print("\nSelecting random image from dataset...")
#         image_path, true_label = get_random_image()

#         prediction, confidence = run_full_pipeline(image_path)

#         show_metrics(true_label, prediction)

#     elif option == "2":

#         image_path = input("Enter full image path: ")

#         if not os.path.exists(image_path):
#             print("Image not found!")
#             exit()

#         prediction, confidence = run_full_pipeline(image_path)

#     else:
#         print("Invalid option selected.")
#         exit()

#     print("\n========== FINAL OUTPUT ==========")
#     print("Prediction :", prediction)
#     print("Confidence :", round(confidence*100,2), "%")

# # ==========================================================
# # AI THYROID DIAGNOSIS PIPELINE
# # Segmentation → ROI Extraction → Classification
# # Professional Medical Visualization
# # ==========================================================

# import os
# import random
# import cv2
# import numpy as np
# import tensorflow as tf
# import matplotlib.pyplot as plt
# from datetime import datetime

# print("\n========== AI THYROID DIAGNOSIS PIPELINE ==========\n")

# # ================= PATH CONFIG =================

# BASE_PATH = r"C:\Users\ELCOT\Desktop\project"

# DATASET_PATH = os.path.join(
#     BASE_PATH,
#     "Thyroid Classification Dataset1",
#     "Thyroid Classification Dataset1"
# )

# MODEL_PATH = os.path.join(
#     BASE_PATH,
#     "saved_models",
#     "thyroid_inception_multiscale.h5"
# )

# # ================= CLASS LABELS =================

# class_labels = ['Malignant', 'benign', 'normal thyroid']

# # ================= LOAD MODEL =================

# print("Loading Classification Model...")

# model = tf.keras.models.load_model(MODEL_PATH)

# print("Model Loaded Successfully")

# # ================= IMAGE SELECTION =================

# print("\nSelect Input Option:")
# print("1 → Use Random Image From Dataset")
# print("2 → Enter Image Path Manually")

# option = input("Enter option (1 or 2): ")

# if option == "1":

#     print("\nSelecting random image from dataset...")

#     all_images = []

#     for root, dirs, files in os.walk(DATASET_PATH):

#         for file in files:

#             if file.lower().endswith((".jpg",".png",".jpeg")):

#                 all_images.append(os.path.join(root, file))

#     image_path = random.choice(all_images)

#     ground_truth = os.path.basename(os.path.dirname(image_path))

# else:

#     image_path = input("Enter full image path: ")

#     ground_truth = "Unknown"

# print("Selected Image:", image_path)
# print("Actual Class:", ground_truth)

# # ================= LOAD IMAGE =================

# image = cv2.imread(image_path)

# if image is None:
#     print("Error loading image")
#     exit()

# original = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

# # ================= SEGMENTATION =================

# print("\nStep 1: Running Segmentation...")

# gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# blur = cv2.GaussianBlur(gray, (5,5), 0)

# _, mask = cv2.threshold(
#     blur,
#     0,
#     255,
#     cv2.THRESH_BINARY + cv2.THRESH_OTSU
# )

# segmented = cv2.bitwise_and(original, original, mask=mask)

# print("Segmentation Completed")

# # ================= ROI EXTRACTION =================

# print("Step 2: Extracting ROI...")

# contours, _ = cv2.findContours(
#     mask,
#     cv2.RETR_EXTERNAL,
#     cv2.CHAIN_APPROX_SIMPLE
# )

# if len(contours) > 0:

#     c = max(contours, key=cv2.contourArea)

#     x,y,w,h = cv2.boundingRect(c)

#     roi = original[y:y+h, x:x+w]

# else:

#     roi = original

# roi = cv2.resize(roi, (224,224))

# print("ROI Extraction Completed")

# # ================= CLASSIFICATION =================

# print("Step 3: Running Classification...")

# try:

#     input_img = roi.astype(np.float32)

#     input_img = input_img / 255.0

#     input_img = np.expand_dims(input_img, axis=0).copy()

#     preds = model.predict(input_img)

#     pred_index = np.argmax(preds)

#     predicted_class = class_labels[pred_index]

#     confidence = float(np.max(preds)) * 100

#     probabilities = preds[0]

#     print("Prediction:", predicted_class)
#     print("Confidence:", confidence)

# except Exception as e:

#     print("Classification Error:", e)

#     predicted_class = "Error"
#     confidence = 0
#     probabilities = [0,0,0]

# # ================= CLINICAL STAGE =================

# if predicted_class == "Malignant":

#     stage = "Cancer Risk (Malignant Nodule)"

# elif predicted_class == "benign":

#     stage = "Benign Thyroid Nodule"

# elif predicted_class == "normal thyroid":

#     stage = "Normal Thyroid Tissue"

# else:

#     stage = "Unknown"

# # ================= VISUALIZATION =================

# plt.figure(figsize=(16,8))

# plt.suptitle(
# f"""
# AI THYROID DIAGNOSIS SYSTEM

# Prediction : {predicted_class.upper()}
# Confidence : {confidence:.2f} %

# Clinical Stage : {stage}

# Model : InceptionV3
# Date : {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
# """,
# fontsize=14,
# fontweight='bold'
# )

# # ORIGINAL IMAGE

# plt.subplot(2,3,1)
# plt.title("Original Ultrasound")
# plt.imshow(original)
# plt.axis("off")

# # SEGMENTATION

# plt.subplot(2,3,2)
# plt.title("AI Segmentation")
# plt.imshow(segmented)
# plt.axis("off")

# # ROI

# plt.subplot(2,3,3)
# plt.title("Extracted ROI")
# plt.imshow(roi)
# plt.axis("off")

# # MASK

# plt.subplot(2,3,4)
# plt.title("Segmentation Mask")
# plt.imshow(mask, cmap='gray')
# plt.axis("off")

# # PROBABILITY CHART

# plt.subplot(2,3,5)

# plt.bar(class_labels, probabilities)

# plt.title("Prediction Probabilities")

# plt.ylabel("Confidence")

# # TEXT PANEL

# plt.subplot(2,3,6)

# plt.axis("off")

# report_text = f"""
# AI Diagnosis Report

# Actual Class : {ground_truth}

# Predicted Class : {predicted_class}

# Confidence : {confidence:.2f} %

# Clinical Interpretation :

# {stage}

# Note:
# This AI prediction assists medical professionals
# and should not replace clinical diagnosis.
# """

# plt.text(
# 0.1,
# 0.5,
# report_text,
# fontsize=11,
# verticalalignment='center'
# )

# plt.tight_layout()

# plt.show()

# print("\n========== DIAGNOSIS COMPLETE ==========\n")



# ==========================================================
# AI THYROID DIAGNOSIS PIPELINE
# Segmentation → ROI → Classification
# + Confusion Matrix + ROC + Performance Metrics
# + Professional PDF Report
# ==========================================================

# ==========================================================
# AI THYROID DIAGNOSIS PIPELINE
# Segmentation → ROI → Classification
# + Confusion Matrix + ROC + Performance Metrics
# + Professional PDF Report
# ==========================================================

import os
import random
import cv2
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt

from datetime import datetime

from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from sklearn.metrics import roc_curve, auc
from sklearn.preprocessing import label_binarize

import seaborn as sns
from matplotlib.backends.backend_pdf import PdfPages

print("\n========== AI THYROID DIAGNOSIS PIPELINE ==========\n")

# ==========================================================
# PATH CONFIGURATION
# ==========================================================

BASE_PATH = r"C:\Users\ELCOT\Desktop\project"

DATASET_PATH = os.path.join(
    BASE_PATH,
    "Thyroid Classification Dataset1",
    "Thyroid Classification Dataset1"
)

MODEL_PATH = os.path.join(
    BASE_PATH,
    "saved_models",
    "thyroid_inception_multiscale.h5"
)

REPORT_PATH = os.path.join(BASE_PATH,"reports")

os.makedirs(REPORT_PATH,exist_ok=True)

# ==========================================================
# CLASS LABELS
# ==========================================================

class_labels = ["benign","malignant","normal thyroid"]

class_map = {
    "benign":1,
    "malignant":0,
    "normal thyroid":2
}

# ==========================================================
# LOAD MODEL
# ==========================================================

print("Loading Model...")

model = tf.keras.models.load_model(MODEL_PATH)

print("Model Loaded Successfully")

# ==========================================================
# SELECT RANDOM IMAGE
# ==========================================================

all_images=[]

for root,dirs,files in os.walk(DATASET_PATH):
    for file in files:
        if file.lower().endswith((".jpg",".png",".jpeg")):
            all_images.append(os.path.join(root,file))

image_path=random.choice(all_images)

ground_truth=os.path.basename(os.path.dirname(image_path))

print("Selected Image:",image_path)
print("Actual Class:",ground_truth)

# ==========================================================
# LOAD IMAGE
# ==========================================================

image=cv2.imread(image_path)

original=cv2.cvtColor(image,cv2.COLOR_BGR2RGB)

# ==========================================================
# SEGMENTATION
# ==========================================================

gray=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)

blur=cv2.GaussianBlur(gray,(5,5),0)

_,mask=cv2.threshold(
    blur,
    0,
    255,
    cv2.THRESH_BINARY+cv2.THRESH_OTSU
)

segmented=cv2.bitwise_and(original,original,mask=mask)

# ==========================================================
# ROI EXTRACTION
# ==========================================================

contours,_=cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)

if len(contours)>0:

    c=max(contours,key=cv2.contourArea)

    x,y,w,h=cv2.boundingRect(c)

    roi=original[y:y+h,x:x+w]

else:

    roi=original

roi=cv2.resize(roi,(224,224))

# ==========================================================
# CLASSIFICATION
# ==========================================================

input_img=roi.astype(np.float32)/255.0
input_img=np.expand_dims(input_img,axis=0)

preds=model.predict(input_img)

pred_index=np.argmax(preds)

predicted_class=class_labels[pred_index]

confidence=float(np.max(preds))*100

probabilities=preds[0]

print("\nPrediction:",predicted_class)
print("Confidence:",confidence)

# ==========================================================
# PROFESSIONAL DASHBOARD
# ==========================================================

fig=plt.figure(figsize=(16,9))

fig.suptitle(
f"""
AI THYROID DIAGNOSIS SYSTEM

Prediction : {predicted_class.upper()}
Confidence : {confidence:.2f} %

Model : InceptionV3
Date : {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
""",
fontsize=16,
fontweight="bold"
)

plt.subplot(2,3,1)
plt.title("Original Ultrasound")
plt.imshow(original)
plt.axis("off")

plt.subplot(2,3,2)
plt.title("Segmentation Result")
plt.imshow(segmented)
plt.axis("off")

plt.subplot(2,3,3)
plt.title("Extracted ROI")
plt.imshow(roi)
plt.axis("off")

plt.subplot(2,3,4)
plt.title("Segmentation Mask")
plt.imshow(mask,cmap="gray")
plt.axis("off")

plt.subplot(2,3,5)

plt.bar(class_labels,probabilities)

plt.title("Prediction Probabilities")

plt.subplot(2,3,6)

plt.axis("off")

plt.text(
0.05,0.6,
f"""
AI Diagnosis Summary

Actual Class : {ground_truth}

Predicted Class : {predicted_class}

Confidence : {confidence:.2f} %


Clinical Interpretation :


Note:
This AI prediction assists medical professionals
and should not replace clinical diagnosis.

""",
fontsize=12
)

plt.tight_layout()

dashboard_path=os.path.join(REPORT_PATH,"dashboard.png")

plt.savefig(dashboard_path)

plt.show(block=False)
plt.pause(3)

plt.close()

# ==========================================================
# PERFORMANCE EVALUATION
# ==========================================================

print("\nEvaluating Model Performance...")

true_labels=[]
pred_labels=[]
prob_scores=[]

for class_name in class_labels:

    class_folder=os.path.join(DATASET_PATH,class_name)

    if not os.path.exists(class_folder):
        continue

    files=os.listdir(class_folder)[:50]

    for file in files:

        img_path=os.path.join(class_folder,file)

        img=cv2.imread(img_path)

        if img is None:
            continue

        img=cv2.resize(img,(224,224))

        img=img.astype(np.float32)/255.0

        img=np.expand_dims(img,axis=0)

        pred=model.predict(img,verbose=0)

        true_labels.append(class_map[class_name])

        pred_labels.append(np.argmax(pred))

        prob_scores.append(pred[0])

true_labels=np.array(true_labels)
pred_labels=np.array(pred_labels)
prob_scores=np.array(prob_scores)

# ==========================================================
# CONFUSION MATRIX
# ==========================================================

cm=confusion_matrix(true_labels,pred_labels)

plt.figure(figsize=(6,5))

sns.heatmap(
cm,
annot=True,
fmt="d",
cmap="Blues",
xticklabels=class_labels,
yticklabels=class_labels
)

plt.title("Confusion Matrix")

conf_path=os.path.join(REPORT_PATH,"confusion_matrix.png")

plt.savefig(conf_path)

plt.show(block=False)
plt.pause(3)
plt.close()

# ==========================================================
# ROC CURVE
# ==========================================================

true_bin=label_binarize(true_labels,classes=[0,1,2])

plt.figure()

for i in range(3):

    fpr,tpr,_=roc_curve(true_bin[:,i],prob_scores[:,i])

    roc_auc=auc(fpr,tpr)

    plt.plot(fpr,tpr,label=f"{class_labels[i]} (AUC={roc_auc:.2f})")

plt.plot([0,1],[0,1],'k--')

plt.xlabel("False Positive Rate")

plt.ylabel("True Positive Rate")

plt.title("ROC Curve")

plt.legend()

roc_path=os.path.join(REPORT_PATH,"roc_curve.png")

plt.savefig(roc_path)

plt.show(block=False)
plt.pause(3)
plt.close()

# ==========================================================
# PERFORMANCE METRICS
# ==========================================================

report=classification_report(
true_labels,
pred_labels,
target_names=class_labels
)

print("\nPerformance Metrics\n")

print(report)


if not os.path.exists(dashboard_path):
    print("Dashboard image missing!") 

    
# ==========================================================
# PDF REPORT GENERATION
# ==========================================================

print("\nGenerating Professional PDF Report...")

pdf_file=os.path.join(
REPORT_PATH,
f"thyroid_ai_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
)

with PdfPages(pdf_file) as pdf:

    img=plt.imread(dashboard_path)

    fig=plt.figure(figsize=(8,10))
    plt.imshow(img)
    plt.axis("off")
    plt.title("AI Diagnosis Dashboard")
    pdf.savefig(fig)
    plt.close()

    img=plt.imread(conf_path)

    fig=plt.figure(figsize=(8,6))
    plt.imshow(img)
    plt.axis("off")
    plt.title("Confusion Matrix")
    pdf.savefig(fig)
    plt.close()

    img=plt.imread(roc_path)

    fig=plt.figure(figsize=(8,6))
    plt.imshow(img)
    plt.axis("off")
    plt.title("ROC Curve")
    pdf.savefig(fig)
    plt.close()

    fig=plt.figure(figsize=(8,10))

    plt.axis("off")

    plt.text(
0.01,0.95,
f"""
AI THYROID DIAGNOSIS REPORT

Predicted Class : {predicted_class}
Confidence : {confidence:.2f} %

Actual Class : {ground_truth}

Performance Metrics

{report}

Generated : {datetime.now()}
""",
fontsize=11,
verticalalignment="top"
)

    pdf.savefig(fig)

    plt.close()

print("\nPDF REPORT SAVED AT:\n",pdf_file)

print("\n========== PIPELINE COMPLETE ==========\n")