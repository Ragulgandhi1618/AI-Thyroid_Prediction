# ==========================================================
# AI THYROID CLASSIFICATION TRAINING
# Transfer Learning with InceptionV3
# ==========================================================

import os
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping
from tensorflow.keras.applications import InceptionV3
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D, Dropout
from tensorflow.keras.models import Model
from sklearn.utils.class_weight import compute_class_weight
import numpy as np

print("\n========== THYROID MODEL TRAINING ==========\n")

# -------------------------------------------------
# PATH CONFIG
# -------------------------------------------------

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.abspath(os.path.join(BASE_DIR, ".."))

DATASET_PATH = os.path.join(
    PROJECT_ROOT,
    "Thyroid Classification Dataset1",
    "Thyroid Classification Dataset1"
)

MODEL_DIR = os.path.join(PROJECT_ROOT, "saved_models")
os.makedirs(MODEL_DIR, exist_ok=True)

MODEL_PATH = os.path.join(MODEL_DIR, "thyroid_inceptionv3_model.h5")

print("Dataset Path:", DATASET_PATH)
print("Model Save Path:", MODEL_PATH)

# -------------------------------------------------
# CHECK DATASET
# -------------------------------------------------

if not os.path.exists(DATASET_PATH):
    raise FileNotFoundError(f"Dataset not found at {DATASET_PATH}")

# -------------------------------------------------
# TRAINING PARAMETERS
# -------------------------------------------------

IMG_SIZE = 224
BATCH_SIZE = 16
EPOCHS = 10

# -------------------------------------------------
# DATA AUGMENTATION
# -------------------------------------------------

datagen = ImageDataGenerator(
    rescale=1./255,
    rotation_range=20,
    zoom_range=0.2,
    horizontal_flip=True,
    validation_split=0.2
)

train_generator = datagen.flow_from_directory(
    DATASET_PATH,
    target_size=(IMG_SIZE, IMG_SIZE),
    batch_size=BATCH_SIZE,
    class_mode="categorical",
    subset="training"
)

val_generator = datagen.flow_from_directory(
    DATASET_PATH,
    target_size=(IMG_SIZE, IMG_SIZE),
    batch_size=BATCH_SIZE,
    class_mode="categorical",
    subset="validation"
)

print("\nDetected Classes:", train_generator.class_indices)

# -------------------------------------------------
# HANDLE CLASS IMBALANCE
# -------------------------------------------------

labels = train_generator.classes

class_weights = compute_class_weight(
    class_weight="balanced",
    classes=np.unique(labels),
    y=labels
)

class_weights = dict(enumerate(class_weights))

print("\nClass Weights:", class_weights)

# -------------------------------------------------
# LOAD PRETRAINED MODEL
# -------------------------------------------------

base_model = InceptionV3(
    weights="imagenet",
    include_top=False,
    input_shape=(IMG_SIZE, IMG_SIZE, 3)
)

for layer in base_model.layers:
    layer.trainable = False

# -------------------------------------------------
# CUSTOM CLASSIFIER HEAD
# -------------------------------------------------

x = base_model.output
x = GlobalAveragePooling2D()(x)
x = Dense(256, activation="relu")(x)
x = Dropout(0.5)(x)
predictions = Dense(train_generator.num_classes, activation="softmax")(x)

model = Model(inputs=base_model.input, outputs=predictions)

# -------------------------------------------------
# COMPILE MODEL
# -------------------------------------------------

model.compile(
    optimizer="adam",
    loss="categorical_crossentropy",
    metrics=[
        "accuracy",
        tf.keras.metrics.Precision(name="precision"),
        tf.keras.metrics.Recall(name="recall"),
        tf.keras.metrics.AUC(name="auc")
    ]
)

model.summary()

# -------------------------------------------------
# CALLBACKS
# -------------------------------------------------

checkpoint = ModelCheckpoint(
    MODEL_PATH,
    monitor="val_accuracy",
    save_best_only=True,
    verbose=1
)

early_stop = EarlyStopping(
    monitor="val_loss",
    patience=3,
    restore_best_weights=True
)

# -------------------------------------------------
# TRAIN MODEL
# -------------------------------------------------

history = model.fit(
    train_generator,
    validation_data=val_generator,
    epochs=EPOCHS,
    class_weight=class_weights,
    callbacks=[checkpoint, early_stop]
)

# -------------------------------------------------
# FINAL SAVE
# -------------------------------------------------

model.save(MODEL_PATH)

print("\n TRAINING COMPLETED SUCCESSFULLY")
print(" Model saved at:", MODEL_PATH)

# -------------------------------------------------
# FINAL METRICS
# -------------------------------------------------

loss, acc, precision, recall, auc = model.evaluate(val_generator)

print("\n========== MODEL PERFORMANCE ==========")
print(f"Accuracy   : {acc*100:.2f}%")
print(f"Precision  : {precision*100:.2f}%")
print(f"Recall     : {recall*100:.2f}%")
print(f"AUC Score  : {auc*100:.2f}%")
print("=======================================")




# import os
# import tensorflow as tf
# from tensorflow.keras import layers, models
# from tensorflow.keras.preprocessing.image import ImageDataGenerator
# from tensorflow.keras.callbacks import ModelCheckpoint

# print("\n========== TRAINING MODULE ==========\n")

# # -------------------------------------------------
# # PATH HANDLING
# # -------------------------------------------------

# BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# PROJECT_ROOT = os.path.abspath(os.path.join(BASE_DIR, ".."))

# DATASET_PATH = os.path.join(
#     PROJECT_ROOT,
#     "Thyroid Classification Dataset1",
#     "Thyroid Classification Dataset1"
# )

# MODEL_DIR = os.path.join(PROJECT_ROOT, "saved_models")
# os.makedirs(MODEL_DIR, exist_ok=True)

# MODEL_PATH = os.path.join(MODEL_DIR, "thyroid_inception_multiscale.h5")

# print("Dataset Path:", DATASET_PATH)
# print("Model Save Path:", MODEL_PATH)

# # -------------------------------------------------
# # CHECK DATASET EXISTS
# # -------------------------------------------------

# if not os.path.exists(DATASET_PATH):
#     raise FileNotFoundError(f"Dataset not found at {DATASET_PATH}")

# # -------------------------------------------------
# # DATA GENERATOR
# # -------------------------------------------------

# IMG_SIZE = 224
# BATCH_SIZE = 8
# EPOCHS = 5  # Keep small for testing first

# datagen = ImageDataGenerator(
#     rescale=1./255,
#     validation_split=0.2
# )

# train_generator = datagen.flow_from_directory(
#     DATASET_PATH,
#     target_size=(IMG_SIZE, IMG_SIZE),
#     batch_size=BATCH_SIZE,
#     class_mode="categorical",
#     subset="training"
# )

# val_generator = datagen.flow_from_directory(
#     DATASET_PATH,
#     target_size=(IMG_SIZE, IMG_SIZE),
#     batch_size=BATCH_SIZE,
#     class_mode="categorical",
#     subset="validation"
# )

# print("Classes:", train_generator.class_indices)

# # -------------------------------------------------
# # SIMPLE CNN MODEL (FAST + SAFE)
# # -------------------------------------------------

# model = models.Sequential([
#     layers.Conv2D(32, (3,3), activation="relu", input_shape=(IMG_SIZE, IMG_SIZE, 3)),
#     layers.MaxPooling2D(2,2),
#     layers.Conv2D(64, (3,3), activation="relu"),
#     layers.MaxPooling2D(2,2),
#     layers.Flatten(),
#     layers.Dense(128, activation="relu"),
#     layers.Dense(train_generator.num_classes, activation="softmax")
# ])

# model.compile(
#     optimizer="adam",
#     loss="categorical_crossentropy",
#     metrics=["accuracy"]
# )

# model.summary()

# # -------------------------------------------------
# # SAVE BEST MODEL
# # -------------------------------------------------

# checkpoint = ModelCheckpoint(
#     MODEL_PATH,
#     monitor="val_accuracy",
#     save_best_only=True,
#     verbose=1
# )

# # -------------------------------------------------
# # TRAIN
# # -------------------------------------------------

# model.fit(
#     train_generator,
#     validation_data=val_generator,
#     epochs=EPOCHS,
#     callbacks=[checkpoint]
# )

# # -------------------------------------------------
# # FINAL SAVE
# # -------------------------------------------------

# model.save(MODEL_PATH)

# print("\n TRAINING COMPLETE")
# print(" Model saved at:", MODEL_PATH)